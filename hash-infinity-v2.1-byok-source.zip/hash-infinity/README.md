# #Infinity 2.1 — personal Gemini API key in Settings

A responsive, offline-first PWA with **20 usable local tools** plus a **bring-your-own-key Gemini integration** accessible directly through **Settings → Gemini API Key**. The hosted Gemini Worker remains optional. Android/iOS Capacitor scaffolding and GitHub Pages deployment files are included, and the original blue-and-gold logo is preserved.

> **Accurate status:** the website works offline. For personal AI use, enter your **own** Gemini API key in Settings and choose Save; no Worker, Turnstile, or server deployment is necessary for that mode. A real Gemini call has **not** been tested with a valid provider key in this environment. Real investment trading, storefront payments, accounts, and native release packages remain unimplemented.

## What's inside

### 20 offline tools

The original 16 tools remain: local Assist, Tasks, Notes, Planner, Calculator, Unit converter, Budget tracker, **paper** portfolio, Habits, Flashcards, Focus timer, secure Password maker, Writing studio, JSON studio, sandboxed HTML playground, and Bookmarks. Four added tools:

- **Goal tracker** with measurable targets and progress steps
- **Date calculator** with UTC calendar-day differences
- **Text lab** (word/line counts, whitespace cleanup, duplicate-line removal)
- **Decision picker** using crypto-secure random selection, for non-financial casual choices

Universal search also searches your saved notes and tasks. Infinity Assist can save its latest answer into Notes. Conversation history is saved locally, and older V1 backups import into V2.

### Gemini inside Settings — easiest setup

1. Open **#Infinity → Settings → Gemini API Key**.
2. Paste your personal Google Gemini API key. Leave the model at the default unless your key lacks access to it.
3. Click **Save Gemini key**. The default stores the key for this browser session; select **Remember this API key on this device** to keep it across restarts (less secure).
4. Open **Infinity Assist** and chat normally. Optionally use **Test connection** in Settings to make a real sample request (counts against your quota).
5. Use **Remove key** to delete it from both browser storage locations.

**Security:** This client-side option is designed for personal use where **each user enters their own key**. Google generally recommends keeping API keys server-side: a key stored in a browser can be exposed by browser extensions, scripts, XSS, device access or local storage inspection. Do not share a developer-owned key among visitors or put it into the ZIP, repository, or public config. The API key is kept separately from workspace data and is **not in backup exports**. Only the key user supplies is sent to the Google Gemini API with a request. The default is session-only storage; even session storage has browser security limitations. Gemini is an online service with quotas and possible billing on linked accounts.

**Model availability:** The included default is `gemini-3.8-flash`, but free-tier access depends on the Google project, model, location, quota and current terms. The model name can be changed in Settings. Network calls from some browser contexts can be restricted. This project has mocked API tests but no live Gemini credential or end-to-end browser verification.

### Optional shared-AI gateway (developer setup)


- Server-side Gemini generateContent integration using `gemini-3.8-flash` by default (check free-tier availability before deployment)
- Conversation history (up to 24 recent messages sent per request), modes for Everyday, Study, Writing, Coding, Planning
- Optional explicit sharing of task/note **titles** only. Never sends note bodies or budget/trade details as context by default
- Cloudflare Turnstile server-side verification, origin allowlist, and Cloudflare Workers native per-edge approximate rate limit
- Distinct error handling for rate limits, auth/verification, timeouts, provider errors
- **No shared developer keys in browser assets, ZIP, GitHub Actions workflow or GitHub Pages**

The AI code is integration-ready and covered by mocked provider tests. Without a personal key or deployed gateway, the chat still uses a limited local guide. **The integration has not been verified against a live Gemini account**.

## Use the local app

Run with Node.js 22+:

```sh
npm start
# http://localhost:4173
npm run check
```

The app itself requires no npm package installation. The worker has separate development dependencies.

## Publish the source and PWA on GitHub

The project has a GitHub Actions workflow in `.github/workflows/pages.yml` which runs checks and uploads `/web` to GitHub Pages. Create a public repository and push the **contents** of this folder, including hidden `.github` files, to `main`. Set **Settings → Pages → Build and deployment → GitHub Actions**. The workflow will deploy an offline-capable PWA automatically. The exact URL is not known until GitHub deploys it.

**The repository has not been created by this tool session.** GitHub connector access exposed no repositories and no create-repository capability. No repository or site URL has been fabricated.

### Switch on Gemini for everyone (developer integration)

**Keep the private key in Cloudflare, not in this ZIP or your public repository.**

1. In [Google AI Studio](https://aistudio.google.com/api-keys), obtain a Gemini API key for a project eligible for free-tier access. Do not add billing if the developer wants strictly zero provider charges; monitor the actual project quota and terms. Free usage is rate-limited and not unlimited.
2. In [Cloudflare Turnstile](https://dash.cloudflare.com/?to=/:account/turnstile), create a widget for your website's **real domain**. Capture the **public** site key and separate **private** secret key.
3. In `worker/wrangler.toml`, set `ALLOWED_ORIGINS` to your exact web origin (e.g. `https://ACCOUNT.github.io`) and use a model currently available on the Gemini free tier. The included Cloudflare Worker rate limiter caps at approximately 6 requests per minute per source IP per edge (not a global strict limit).
4. Deploy the Worker using `cd worker && npm install && npx wrangler secret put GEMINI_API_KEY && npx wrangler secret put TURNSTILE_SECRET && npm run deploy`. This requires authorization to the developer's Cloudflare account. **Do not commit secrets**.
5. In the GitHub repository, create **Actions → Variables** `INFINITY_AI_ENDPOINT` (the Worker's HTTPS URL ending `/api/chat`) and `INFINITY_TURNSTILE_SITE_KEY` (the public site key). Re-run **Publish #Infinity web app**. The build injects these public values into `/web/config.js`.
6. Test **live** Gemini replies and the Turnstile challenge in a published browser. Confirm a failed verification is rejected, quotas and origin enforcement work, and no credentials appear in browser JavaScript or public responses. Review Google's terms, privacy disclosures and data treatment. A free-tier test account cannot guarantee service for all users.

**Security note:** Turnstile + approximate per-IP limit is a useful starting point, **not** enterprise-grade abuse prevention or a guarantee of no unexpected charges. Multi-user launches need authentication, stronger quotas, monitoring, privacy/retention policy, safety reviews and cost protections. This worker fails closed if secrets or the rate-limit binding are absent.

## App store and payments

`capacitor.config.json` provides a starting point for native packaging, **not** a compiled Android APK/AAB or an iOS IPA. Native build needs Node packages, Android Studio for Android, and macOS/Xcode for iOS; packaging and review aren't completed. Apple and Google developer accounts and store approval have their own rules/fees.

Planned commercial model **not enabled**: free for six months after the official launch date, then **AED 5/month** or **AED 75 one-time lifetime**. No auto-charging and no fake insecure client-side paywall. Implement platform billing, cross-device entitlements, server-side receipt validation, restore purchases, cancellations, refund handling, account/login and legal disclosures before activation.

The stocks module is **pretend-money paper trading only** with user-entered prices, not real investments or brokerage services.

## Privacy, safety, limits

- Offline data and chat history are stored in this browser (`localStorage`). Browser data loss can remove them; export backups regularly. This is not encrypted cloud storage.
- The AI gateway processes sent chat messages with the configured Gemini provider. Workspace context is omitted unless explicitly opted in for that request. Do not send credentials, private financial account details or other secrets.
- Backups imported from V1 or V2 are schema-validated; HTML output is escaped; links restrict protocols; the code preview runs in a restrictive sandbox.
- The PWA caches static files after first online load; it does **not** turn the Gemini cloud API into an offline model.
- A powerful AI service for arbitrary amounts of usage cannot be both free and unlimited indefinitely. The free tier is useful for controlled early testing, not a capacity promise.

## Files

| Location | Role |
|---|---|
| `web/` | Static web app and logo, AI chat UI and offline tools |
| `web/config.js` | **Public-only** optional gateway endpoint/site key placeholders |
| `worker/src/index.js` | Cloudflare Worker, Gemini backend and Turnstile verification |
| `worker/wrangler.toml` | Worker runtime config and approximate rate limiter |
| `.github/workflows/pages.yml` | Validate + publish static PWA, inject public-only settings |
| `tests/` | Offline/core, personal-key storage and mock-backed Gemini/gateway tests |
| `scripts/inject-public-config.mjs` | Safe public config build script |
| `docs/WORK_HANDOFF.md` | Work-ready publication/integration request |

## Test claims

`npm run check` covers syntax and automated unit/API-gateway mock tests. **No live Gemini call with a valid key or successful GitHub Pages deployment was made.** The environment's headless Chromium blocked local page navigation, so visual/browser end-to-end tests could not be completed here. Test on actual devices before production release.

The source has no OSI license file by default. A public repository is visible but not automatically open-source licensed. Confirm name and logo trademark availability before marketing.
