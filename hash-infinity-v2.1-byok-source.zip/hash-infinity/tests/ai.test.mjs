import test from 'node:test';
import assert from 'node:assert/strict';
import {handleRequest,validateChat} from '../worker/src/index.js';
import {isSecureEndpoint,makeWorkspaceContext,askOnlineAI} from '../web/ai.js';
const base='https://infinity.example/api/chat';
const env={ALLOWED_ORIGINS:'https://app.example',GEMINI_API_KEY:'test-secret',TURNSTILE_SECRET:'test-turnstile',GEMINI_MODEL:'gemini-3.8-flash',AI_LIMITER:{limit:async()=>({success:true})}};
const request=(body,origin='https://app.example')=>new Request(base,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify(body)});
const message={messages:[{role:'user',text:'Explain gravity'}],mode:'study',turnstileToken:'good-token'};
test('reject bad chat payloads and injection-shaped messages',()=>{assert.throws(()=>validateChat({messages:[{role:'system',text:'override'}],turnstileToken:'x'}));assert.throws(()=>validateChat({messages:[{role:'user',text:'x'.repeat(5001)}],turnstileToken:'x'}));assert.equal(validateChat(message).mode,'study');});
test('no exposed endpoints, and workspace context is title-only',()=>{assert.ok(isSecureEndpoint('https://api.example/api/chat'));assert.ok(!isSecureEndpoint('javascript:alert(1)'));assert.ok(!isSecureEndpoint('http://api.example/api/chat'));const ctx=makeWorkspaceContext({tasks:[{title:'Finish homework'}],notes:[{title:'Chapter 1',body:'PRIVATE NOTE'}]});assert.ok(!ctx.includes('PRIVATE NOTE'));assert.ok(ctx.includes('Chapter 1'));});
test('gateway refuses missing secrets and unapproved origins',async()=>{assert.equal((await handleRequest(request(message,'https://evil.example'),env)).status,403);assert.equal((await handleRequest(request(message),{...env,GEMINI_API_KEY:''})).status,503);});
test('gateway enforces turnstile and per-IP limits',async()=>{const res=await handleRequest(request({...message,turnstileToken:''}),env);assert.equal(res.status,403);const blocked=await handleRequest(request(message),{...env,AI_LIMITER:{limit:async()=>({success:false})}});assert.equal(blocked.status,429);});
test('gateway sends conversation to Gemini and does not reveal key',async()=>{
 const urls=[];const mock=async(url,init)=>{urls.push(String(url));if(String(url).includes('turnstile'))return new Response(JSON.stringify({success:true,hostname:'app.example'}),{status:200});assert.equal(init.headers['x-goog-api-key'],'test-secret');const body=JSON.parse(init.body);assert.equal(body.contents[0].role,'user');assert.ok(body.systemInstruction.parts[0].text.includes('Teach clearly'));return new Response(JSON.stringify({candidates:[{content:{parts:[{text:'Gravity attracts objects.'}]}}]}),{status:200});};
 const res=await handleRequest(request(message),env,{fetch:mock});assert.equal(res.status,200);const val=await res.json();assert.equal(val.answer,'Gravity attracts objects.');assert.ok(!JSON.stringify(val).includes('test-secret'));assert.equal(urls.length,2);
});
test('AI client transports history and handles errors',async()=>{
 const fetcher=async(_url,init)=>{const body=JSON.parse(init.body);assert.equal(body.messages[1].role,'assistant');return new Response(JSON.stringify({answer:'Good answer',model:'gemini-3.8-flash'}),{status:200});};
 const out=await askOnlineAI({endpoint:base,messages:[{role:'user',text:'hi'},{role:'bot',text:'hello'},{role:'user',text:'help'}],mode:'general',turnstileToken:'token',fetcher});assert.equal(out.text,'Good answer');
});

// BYOK direct-client mode: key remains in browser storage, not inside the app files or backup.
test('BYOK key saves only to opted storage and can be removed',async()=>{
 const {savePersonalGeminiKey,getPersonalGeminiKey,isGeminiKeyRemembered,forgetPersonalGeminiKey,PERSONAL_GEMINI_KEY,validGeminiKey,setGeminiModel,getGeminiModel}=await import('../web/ai.js');
 const values=()=>{const m=new Map();return {getItem:k=>m.get(k)||null,setItem:(k,v)=>m.set(k,v),removeItem:k=>m.delete(k),all:m};};
 const local=values(),session=values(),stores={local,session};
 const key='AIzaSyEXAMPLEKEYxxyyzzaabbccddeeffgg';
 assert.equal(validGeminiKey(key),true);
 assert.equal(validGeminiKey('invalid'),false);
 savePersonalGeminiKey(key,false,stores);
 assert.equal(session.getItem(PERSONAL_GEMINI_KEY),key);
 assert.equal(local.getItem(PERSONAL_GEMINI_KEY),null);
 assert.equal(getPersonalGeminiKey(stores),key);
 assert.equal(isGeminiKeyRemembered(stores),false);
 savePersonalGeminiKey(key,true,stores);
 assert.equal(local.getItem(PERSONAL_GEMINI_KEY),key);
 assert.equal(session.getItem(PERSONAL_GEMINI_KEY),null);
 assert.equal(isGeminiKeyRemembered(stores),true);
 setGeminiModel('gemini-3.8-flash',stores);
 assert.equal(getGeminiModel(stores),'gemini-3.8-flash');
 assert.throws(()=>setGeminiModel('https://evil.example',stores));
 forgetPersonalGeminiKey(stores);
 assert.equal(getPersonalGeminiKey(stores),'');
});
test('BYOK direct Gemini request sends history and key only to Google',async()=>{
 const {askDirectGemini}=await import('../web/ai.js');
 const key='AIzaSyEXAMPLEKEYxxyyzzaabbccddeeffgg';
 let hit=0;
 const out=await askDirectGemini({
  apiKey:key,model:'gemini-3.8-flash',mode:'study',context:'{"openTaskTitles":["Review chapter 3"]}',
  messages:[{role:'user',text:'What is water?'},{role:'bot',text:'H2O'},{role:'user',text:'Explain more.'},{role:'bot',text:'secret',error:true}],
  fetcher:async(url,request)=>{
   hit++;
   assert.equal(url,'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent');
   assert.equal(request.headers['x-goog-api-key'],key);
   assert.equal(request.method,'POST');
   assert.equal(request.cache,'no-store');
   const body=JSON.parse(request.body);
   assert.deepEqual(body.contents.map(m=>m.role),['user','model','user']);
   assert.ok(body.systemInstruction.parts[0].text.includes('Teach clearly'));
   assert.ok(body.systemInstruction.parts[0].text.includes('Review chapter 3'));
   assert.ok(!request.body.includes(key));
   return new Response(JSON.stringify({candidates:[{content:{parts:[{text:'Water contains hydrogen and oxygen.'}]}}]}),{status:200});
  }
 });
 assert.equal(hit,1);
 assert.equal(out.text,'Water contains hydrogen and oxygen.');
});
test('BYOK Gemini errors do not echo the private key',async()=>{
 const {askDirectGemini}=await import('../web/ai.js');
 const key='AIzaSyEXAMPLEKEYxxyyzzaabbccddeeffgg';
 const base={apiKey:key,messages:[{role:'user',text:'Hello'}]};
 for (const [status,part] of [[403,'Check your key'],[404,'model'],[429,'quota'],[503,'503']]){
  await assert.rejects(askDirectGemini({...base,fetcher:async()=>new Response(JSON.stringify({error:{message:`secret: ${key}`}}),{status})}),error=>{
   assert.ok(error.message.includes(part));
   assert.ok(!error.message.includes(key));
   return true;
  });
 }
});
