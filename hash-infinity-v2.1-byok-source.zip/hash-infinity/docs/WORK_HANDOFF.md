# Work handoff — #Infinity 2.1

Use my uploaded **hash-infinity-v2.1-byok-source.zip** as the source of truth. It includes the existing blue-and-gold icon, 20 local tools, GitHub Pages workflow and a personal Gemini API key field in Settings, plus an optional protected Gemini AI gateway.

1. Review the complete source and `README.md`; run `npm run check`. Do not replace or rebrand the logo.
2. Using my connected **GitHub** account, create a **public** repository named `hash-infinity` if allowed and not already present. Upload every file (including `.github/`) to `main`. If the connector cannot create repositories, use the supported Work Cloud Browser workflow after my approval, not an invented URL. Do not expose secrets.
3. Configure GitHub Pages to use GitHub Actions and confirm the **actual** Pages URL after deployment.
4. The **personal-key Gemini mode works without a Worker** after an individual user adds their key in the app. Do not put or commit any personal keys in the repository, even for testing. If Cloudflare and Google AI Studio access is connected and I authorize the secrets, deploy the included `worker/` to Cloudflare Workers with the real Gemini API key and Turnstile secret stored only in secrets. Use free-tier-compatible models and test the limits. Never expose a private key in public frontend code, action logs, source or browser.
5. **Only if the optional shared gateway is deployed**, set repository **Actions Variables** `INFINITY_AI_ENDPOINT` and `INFINITY_TURNSTILE_SITE_KEY` for the **public** values only. Re-run Pages and test live AI chat, follow-ups, error handling, Turnstile and mobile.
6. Fix validated issues; run manual browser/mobile tests if available. Only report functions, releases, deployment and AI calls that actually succeeded.
7. Preserve honest limitations: educational simulated trading only; billing proposed AED 5/mo and AED 75 lifetime after first 6 months, not activated until properly implemented with store-compliant payment/entitlement systems. No automatic charges.
8. Native app stores are a later milestone. Do not claim APK/AAB/IPA or store listings exist unless actually built/released.

Deliver the actual repository/site links if published, a list of verified tests, and a remaining deployment checklist. Avoid asking me to run commands if Work can safely perform the steps with connected accounts.
