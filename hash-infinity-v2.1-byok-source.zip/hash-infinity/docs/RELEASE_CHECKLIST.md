# #Infinity 2.1 release gates

- [x] Source ZIP contains static PWA, existing brand icon, personal Gemini key Settings, optional protected gateway and deployment workflow
- [x] Automated project tests and JavaScript syntax checks pass
- [x] Offline version 1 data structure migrated into v2 import format
- [ ] Real visual/browser tests on desktop/mobile (headless browser blocked by environment admin policy)
- [ ] Create and verify public GitHub repository
- [ ] GitHub Actions Pages deployment succeeds and published URL works
- [x] BYOK Settings UI and mocked direct Gemini API tests
- [ ] Live Gemini request with a valid personal key (none was provided to this build)
- [ ] Connect Google Gemini free-tier project for *optional shared gateway* (no shared key committed)
- [ ] Optional: deploy Worker with Gemini key and Turnstile secret stored in protected secrets
- [ ] Verify origin restriction, Turnstile, actual model call, rate limits, failures
- [ ] Review privacy policy, model provider data use, abuse safety and operational costs
- [ ] Build, sign and test native Android/iOS packages
- [ ] Add real account/payment entitlements, refunds/cancellation flows, store billing
- [ ] App-store submissions and approvals
