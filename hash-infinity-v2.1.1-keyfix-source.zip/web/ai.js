/** Frontend AI transport; no shared API keys are shipped to the browser. */
export function isSecureEndpoint(endpoint) {
  try {const u=new URL(endpoint);return ((u.protocol==='https:' && u.username==='' && u.password==='') || (u.protocol==='http:' && ['localhost','127.0.0.1'].includes(u.hostname))) && u.pathname.endsWith('/api/chat');}catch{return false;}
}
export function makeWorkspaceContext(data) {
  const tasks=(data.tasks||[]).filter(t=>!t.done).slice(0,8).map(t=>String(t.title||'').slice(0,100));
  const noteTitles=(data.notes||[]).slice(0,6).map(n=>String(n.title||'Untitled').slice(0,100));
  return JSON.stringify({openTaskTitles:tasks,noteTitles}); // No note bodies or financial records.
}
export async function askOnlineAI({endpoint,messages,mode,context='',turnstileToken,signal,fetcher=globalThis.fetch}) {
  if(!isSecureEndpoint(endpoint))throw new Error('AI endpoint has not been configured securely.');
  if(!turnstileToken)throw new Error('Complete the verification before sending a message.');
  const response=await fetcher(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:messages.filter(m=>!m.error).slice(-24).map(m=>({role:m.role==='bot'?'assistant':m.role,text:m.text})),mode,context,turnstileToken}),signal,cache:'no-store'});
  const data=await response.json().catch(()=>({}));
  if(!response.ok)throw new Error(String(data.error||`AI request failed (${response.status}).`).slice(0,300));
  if(typeof data.answer!=='string'||!data.answer.trim())throw new Error('The AI returned no answer.');
  return {text:data.answer.slice(0,30000),model:String(data.model||'Gemini')};
}


/** Bring-your-own Gemini key: it never goes into the published app files or exported backups.
 * Session storage is the default; optional device persistence is less secure.
 */
export const PERSONAL_GEMINI_KEY = 'hash-infinity-gemini-key-v1';
export const PERSONAL_GEMINI_MODEL = 'hash-infinity-gemini-model-v1';
export const DEFAULT_GEMINI_MODEL = 'gemini-3.8-flash';
// Google AI Studio issues both AIza-prefixed and newer AQ.-prefixed keys.
// This is only a format check; it does not verify provider access.
export function validGeminiKey(value) {return typeof value === 'string' && /^[A-Za-z0-9_.-]{20,250}$/.test(value.trim());}
export function validGeminiModel(value) {return typeof value === 'string' && /^gemini-[a-z0-9][a-z0-9.-]{2,79}$/.test(value.trim());}
export function getPersonalGeminiKey({local=globalThis.localStorage,session=globalThis.sessionStorage}={}) {
  try { return String(session?.getItem(PERSONAL_GEMINI_KEY) || local?.getItem(PERSONAL_GEMINI_KEY) || ''); }
  catch { return ''; }
}
export function isGeminiKeyRemembered({local=globalThis.localStorage}={}) {
  try { return Boolean(local?.getItem(PERSONAL_GEMINI_KEY)); } catch { return false; }
}
export function savePersonalGeminiKey(value,remember=false,{local=globalThis.localStorage,session=globalThis.sessionStorage}={}) {
  const key=String(value||'').trim();
  if(!validGeminiKey(key)) throw new Error('Enter a valid Gemini API key.');
  if(!local || !session) throw new Error('Browser storage is unavailable.');
  try {
    local.removeItem(PERSONAL_GEMINI_KEY);
    session.removeItem(PERSONAL_GEMINI_KEY);
    (remember?local:session).setItem(PERSONAL_GEMINI_KEY,key);
  } catch { throw new Error('Unable to save the API key in this browser.'); }
}
export function forgetPersonalGeminiKey({local=globalThis.localStorage,session=globalThis.sessionStorage}={}) {
  try { local?.removeItem(PERSONAL_GEMINI_KEY); } catch {}
  try { session?.removeItem(PERSONAL_GEMINI_KEY); } catch {}
}
export function getGeminiModel({local=globalThis.localStorage}={}){
  try {const model=local?.getItem(PERSONAL_GEMINI_MODEL);return validGeminiModel(model)?model:DEFAULT_GEMINI_MODEL;}
  catch{return DEFAULT_GEMINI_MODEL;}
}
export function setGeminiModel(model,{local=globalThis.localStorage}={}){
  if(!validGeminiModel(model))throw new Error('Model name must begin with gemini-.');
  try{local?.setItem(PERSONAL_GEMINI_MODEL,model.trim());}catch{throw new Error('Cannot save the model setting.');}
}
const ASSIST_MODES={
 general:'Be a knowledgeable, truthful assistant. Be concise when possible, explain uncertainty, and do not fabricate facts.',
 study:'Teach clearly using examples and accurate reasoning. Encourage understanding and respect any scope or syllabus specified by the user.',
 write:'Be an expert writing editor. Produce clear, original text adapted to the user’s requested style.',
 code:'Be a careful software engineer. Write secure, correct code, explain trade-offs and avoid unsupported claims.',
 plan:'Help the user plan realistic steps, dependencies, schedules and priorities.'
};
/** Calls Gemini directly with a key entered by this individual user.
 * No proxy or Turnstile needed. Note that browser-side keys are less secure.
 */
export async function askDirectGemini({apiKey,model=DEFAULT_GEMINI_MODEL,messages,mode='general',context='',signal,fetcher=globalThis.fetch}){
  if(globalThis.location && !(location.protocol==='https:' || (location.protocol==='http:' && ['localhost','127.0.0.1'].includes(location.hostname))))throw new Error('Open #Infinity on HTTPS (or localhost) before using an API key.');
  if(!validGeminiKey(apiKey))throw new Error('Add your Gemini API key in Settings first.');
  if(!validGeminiModel(model))throw new Error('Invalid Gemini model name.');
  if(!Array.isArray(messages))throw new Error('Messages must be a list.');
  const contents=messages.filter(m=>m && !m.error && (m.role==='user'||m.role==='bot'||m.role==='assistant') && typeof m.text==='string')
    .slice(-24).map(m=>({role:m.role==='user'?'user':'model',parts:[{text:m.text.slice(0,5000)}]}));
  if(!contents.length||contents.at(-1).role!=='user')throw new Error('Enter a message first.');
  const systemText=(ASSIST_MODES[mode]||ASSIST_MODES.general)+' Your name is Infinity Assist. Never claim access to private data or real-time services you have not been given.'+
    (context?' The user explicitly opted to provide the following workspace titles, for this request only: '+String(context).slice(0,1800):'');
  const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  let response;
  try{response=await fetcher(url,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':apiKey.trim()},body:JSON.stringify({systemInstruction:{parts:[{text:systemText}]},contents,generationConfig:{maxOutputTokens:4096,temperature:0.7}}),cache:'no-store',signal});}
  catch(error){if(error?.name==='AbortError')throw error;throw new Error('Could not reach Gemini. Check your internet connection or browser network permissions.');}
  const data=await response.json().catch(()=>({}));
  if(!response.ok){
    const status=response.status;
    if(status===401){
      const tokenError=String(data?.error?.status||'')+' '+String(data?.error?.message||'');
      if(/ACCESS_TOKEN_TYPE_UNSUPPORTED/i.test(tokenError))throw new Error('Google rejected this API-key type (401: ACCESS_TOKEN_TYPE_UNSUPPORTED). Some newer AQ. keys are affected; check Google AI Studio or create a replacement key.');
      throw new Error('Gemini authorization failed (401). Check the key in Google AI Studio.');
    }
    if(status===403)throw new Error('Gemini access denied (403). Check whether this project can use the selected model and free tier.');
    if(status===400)throw new Error('Gemini rejected the request (400). Check the selected model and request settings.');
    if(status===404)throw new Error('This model is unavailable for your API key. Try another Gemini model in Settings.');
    if(status===429)throw new Error('Gemini free-tier quota or rate limit reached. Try again later.');
    throw new Error(`Gemini request failed (${status}).`);
  }
  const answer=(data?.candidates?.[0]?.content?.parts||[]).map(p=>typeof p.text==='string'?p.text:'').join('').trim();
  if(!answer)throw new Error(data?.promptFeedback?.blockReason?'Gemini blocked this request.':'Gemini returned no text.');
  return {text:answer.slice(0,30000),model};
}
