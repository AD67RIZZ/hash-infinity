import test from 'node:test';
import assert from 'node:assert/strict';
import { calc,convert,portfolio,escapeHtml,safeImport,clone,DEFAULT_STATE,formatMoney,validHttpUrl,monthExpenses,daysBetween,secureRandomIndex } from '../web/core.js';
test('arithmetic with brackets, powers and decimals',()=>{assert.equal(calc('2+3*4'),14);assert.equal(calc('(2+3)*4'),20);assert.equal(calc('2^3'),8);assert.equal(calc('2^3^2'),512);assert.equal(calc('-2^2'),-4);assert.equal(calc('2^-2'),0.25);assert.equal(calc('0.1+0.2').toFixed(1),'0.3');});
test('unsafe and impossible expressions rejected',()=>{assert.throws(()=>calc('alert(1)'));assert.throws(()=>calc('1/0'));assert.throws(()=>calc('2+'));assert.throws(()=>calc('1+'.repeat(80)));});
test('units convert accurately',()=>{assert.equal(convert(1,'length','km','m'),1000);assert.equal(convert(32,'temperature','°F','°C'),0);assert.equal(convert(0,'temperature','°C','K'),273.15);assert.equal(convert(1,'data','MiB','KiB'),1024);});
test('paper portfolio enforces accounting',()=>{const trades=[{ticker:'X',qty:2,price:100,side:'buy'},{ticker:'X',qty:1,price:150,side:'sell'}];const p=portfolio(trades,{X:200});assert.equal(p.cash,9950);assert.equal(p.equity,10150);assert.equal(p.positions[0].qty,1);});
test('HTML is escaped and urls are safe',()=>{assert.equal(escapeHtml('<img src=x onerror="hi">'),'&lt;img src=x onerror=&quot;hi&quot;&gt;');assert.equal(validHttpUrl('javascript:alert(1)'),null);assert.equal(validHttpUrl('https://example.com'), 'https://example.com/');});
test('backup schema protects the data shape',()=>{const s=clone(DEFAULT_STATE);s.tasks=[{id:'1',title:'Try'}];assert.equal(safeImport(s).tasks[0].title,'Try');assert.throws(()=>safeImport({version:99}));assert.equal(safeImport({...s,profile:{theme:'inject',name:'Test'}}).profile.theme,'dark');});
test('spending total and currency',()=>{assert.equal(monthExpenses([{date:'2026-11-12',amount:15},{date:'2026-10-05',amount:2}],new Date(2026,10,21)),15);assert.ok(formatMoney(5).includes('5.00'));});

test('V1 imports migrate and unsafe bookmark URLs cannot survive',()=>{
 const legacy=clone(DEFAULT_STATE);legacy.version=1;legacy.bookmarks=[{id:'unsafe',title:'Bad',url:'javascript:alert(1)'},{id:'safe',title:'Good',url:'https://example.com'}];
 const next=safeImport(legacy);assert.equal(next.version,2);assert.equal(next.bookmarks.length,1);assert.equal(next.bookmarks[0].url,'https://example.com/');
});
test('calendar day differences handle DST/leap years/older dates',()=>{
 assert.equal(daysBetween('2026-11-01','2026-11-21'),20);assert.equal(daysBetween('2024-02-28','2024-03-01'),2);assert.equal(daysBetween('2026-11-21','2026-11-01'),-20);assert.equal(daysBetween('0099-01-01','0099-01-02'),1);assert.throws(()=>daysBetween('2026-02-30','2026-03-01'));
});
test('secure random index always selects valid bounds',()=>{for(let n of [1,2,9,27])for(let i=0;i<100;i++){const x=secureRandomIndex(n);assert.ok(x>=0&&x<n);}});
