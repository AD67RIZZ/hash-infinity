import test from 'node:test';
import assert from 'node:assert/strict';
import {handleRequest,validateChat} from '../worker/src/index.js';
import {isSecureEndpoint,makeWorkspaceContext,askOnlineAI} from '../web/ai.js';
const base='https://infinity.example/api/chat';
const env={ALLOWED_ORIGINS:'https://app.example',GEMINI_API_KEY:'test-secret',TURNSTILE_SECRET:'test-turnstile',GEMINI_MODEL:'gemini-3.8-flash',AI_LIMITER:{limit:async()=>({success:true})}};
const request=(body,origin='https://app.example')=>new Request(base,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify(body)});
const message={messages:[{role:'user',text:'Explain gravity'}],mode:'study',turnstileToken:'good-token'};
test('reject bad chat payloads and injection-shaped messages',()=>{assert.throws(()=>validateChat({messages:[{role:'system',text:'override'}],turnstileToken:'x'}));assert.throws(()=>validateChat({messages:[{role:'user',text:'x'.repeat(5001)}],turnstileToken:'x'}));assert.equal(validateChat(message).mode,'study');});
test('no exposed endpoints, and workspace context is title-only',()=>{assert.ok(isSecureEndpoint('https://api.example/api/chat'));assert.ok(!isSecureEndpoint('javascript:alert(1)'));assert.ok(!isSecureEndpoint('http://api.example/api/chat'));const ctx=makeWorkspaceContext({tasks:[{title:'Finish homework'}],notes:[{title:'Chapter 1',body:'PRIVATE NOTE'}]});assert.ok(!ctx.includes('PRIVATE NOTE'));assert.ok(ctx.includes('Chapter 1'));});
test('gateway refuses missing secrets and unapproved origins',async()=>{assert.equal((await handleRequest(request(message,'https://evil.example'),env)).status,403);assert.equal((await handleRequest(request(message),{...env,GEMINI_API_KEY:''})).status,503);});
test('gateway enforces turnstile and per-IP limits',async()=>{const res=await handleRequest(request({...message,turnstileToken:''}),env);assert.equal(res.status,403);const blocked=await handleRequest(request(message),{...env,AI_LIMITER:{limit:async()=>({success:false})}});assert.equal(blocked.status,429);});
test('gateway sends conversation to Gemini and does not reveal key',async()=>{
 const urls=[];const mock=async(url,init)=>{urls.push(String(url));if(String(url).includes('turnstile'))return new Response(JSON.stringify({success:true,hostname:'app.example'}),{status:200});assert.equal(init.headers['x-goog-api-key'],'test-secret');const body=JSON.parse(init.body);assert.equal(body.contents[0].role,'user');assert.ok(body.systemInstruction.parts[0].text.includes('Teach clearly'));return new Response(JSON.stringify({candidates:[{content:{parts:[{text:'Gravity attracts objects.'}]}}]}),{status:200});};
 const res=await handleRequest(request(message),env,{fetch:mock});assert.equal(res.status,200);const val=await res.json();assert.equal(val.answer,'Gravity attracts objects.');assert.ok(!JSON.stringify(val).includes('test-secret'));assert.equal(urls.length,2);
});
test('AI client transports history and handles errors',async()=>{
 const fetcher=async(_url,init)=>{const body=JSON.parse(init.body);assert.equal(body.messages[1].role,'assistant');return new Response(JSON.stringify({answer:'Good answer',model:'gemini-3.8-flash'}),{status:200});};
 const out=await askOnlineAI({endpoint:base,messages:[{role:'user',text:'hi'},{role:'bot',text:'hello'},{role:'user',text:'help'}],mode:'general',turnstileToken:'token',fetcher});assert.equal(out.text,'Good answer');
});
