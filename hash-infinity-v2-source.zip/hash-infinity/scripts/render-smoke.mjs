/** Limited DOM-free render smoke test. NOT a substitute for actual browser testing. */
const appElement = {innerHTML:'', handlers:{},addEventListener(name,cb){this.handlers[name]=cb;},querySelector(){return null;}};
const pageElement = {innerHTML:'', scrollTop:0};
globalThis.document={getElementById(id){return id==='app'?appElement:id==='page'?pageElement:null;},querySelector(){return null;},addEventListener(){}};
globalThis.localStorage={getItem(){return null;},setItem(){}};
globalThis.window={scrollTo(){}};
await import('../web/app.js');
const ids=['home','explore','assistant','tasks','notes','planner','calculator','converter','finance','markets','habits','study','focus','password','writing','json','code','bookmarks','goals','datecalc','textlab','picker','settings'];
for(const id of ids){
 const fakeButton={dataset:{nav:id},matches(selector){return selector==='[data-nav]';}};
 appElement.handlers.click({target:{closest(){return fakeButton;}},preventDefault(){}});
 if(!pageElement.innerHTML || pageElement.innerHTML.length<100)throw new Error(`View did not render: ${id}`);
}
console.log(`Smoke-rendered ${ids.length} screen layouts without JavaScript exceptions.`);
process.exit(0); // app timers are intentionally recurring
