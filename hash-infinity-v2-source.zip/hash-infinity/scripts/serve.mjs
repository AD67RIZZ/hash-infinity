import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, sep, extname } from 'node:path';
const root=resolve('web');
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.webmanifest':'application/manifest+json','.json':'application/json'};
const port=Number(process.env.PORT||4173);
createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://localhost');const path=decodeURIComponent(url.pathname);
  const file=resolve(root,`.${path==='/'?'/index.html':path}`);
  if(file!==root&&!file.startsWith(`${root}${sep}`)){res.writeHead(403);res.end('Forbidden');return;}
  if(!(await stat(file)).isFile()){res.writeHead(404);res.end('Not found');return;}
  const bytes=await readFile(file);
  res.writeHead(200,{'Content-Type':types[extname(file)]||'application/octet-stream','X-Content-Type-Options':'nosniff','Cache-Control':'no-cache'});res.end(bytes);
 }catch{res.writeHead(404);res.end('Not found');}
}).listen(port,()=>console.log(`#Infinity local preview: http://localhost:${port}`));
