import { writeFile } from 'node:fs/promises';
const endpoint=(process.env.INFINITY_AI_ENDPOINT||'').trim();
const key=(process.env.INFINITY_TURNSTILE_SITE_KEY||'').trim();
if(endpoint){const url=new URL(endpoint);if(url.protocol!=='https:'||!url.pathname.endsWith('/api/chat')||url.username||url.password)throw new Error('Invalid public AI endpoint.');}
if(key && !/^[A-Za-z0-9._-]{5,128}$/.test(key))throw new Error('Invalid public Turnstile site key.');
const content=`/** PUBLIC config generated at deployment. NEVER store any Gemini or Turnstile secret here. */\nexport const AI_CONFIG = Object.freeze(${JSON.stringify({endpoint,turnstileSiteKey:key},null,2)});\n`;
await writeFile(new URL('../web/config.js',import.meta.url),content);
console.log(`Public AI endpoint: ${endpoint?'configured':'not configured'}, Turnstile public site key: ${key?'configured':'not configured'}`);
