/** PUBLIC deployment settings only. Never put an API key or a secret here. */
export const AI_CONFIG = Object.freeze({
  endpoint: '', // e.g. 'https://hash-infinity-ai.example.workers.dev/api/chat'
  turnstileSiteKey: '' // PUBLIC site key only; private Turnstile SECRET lives in Worker
});
