/** Frontend AI transport; no shared API keys are shipped to the browser. */
export function isSecureEndpoint(endpoint) {
  try {const u=new URL(endpoint);return ((u.protocol==='https:' && u.username==='' && u.password==='') || (u.protocol==='http:' && ['localhost','127.0.0.1'].includes(u.hostname))) && u.pathname.endsWith('/api/chat');}catch{return false;}
}
export function makeWorkspaceContext(data) {
  const tasks=(data.tasks||[]).filter(t=>!t.done).slice(0,8).map(t=>String(t.title||'').slice(0,100));
  const noteTitles=(data.notes||[]).slice(0,6).map(n=>String(n.title||'Untitled').slice(0,100));
  return JSON.stringify({openTaskTitles:tasks,noteTitles}); // No note bodies or financial records.
}
export async function askOnlineAI({endpoint,messages,mode,context='',turnstileToken,signal,fetcher=globalThis.fetch}) {
  if(!isSecureEndpoint(endpoint))throw new Error('AI endpoint has not been configured securely.');
  if(!turnstileToken)throw new Error('Complete the verification before sending a message.');
  const response=await fetcher(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:messages.filter(m=>!m.error).slice(-24).map(m=>({role:m.role==='bot'?'assistant':m.role,text:m.text})),mode,context,turnstileToken}),signal,cache:'no-store'});
  const data=await response.json().catch(()=>({}));
  if(!response.ok)throw new Error(String(data.error||`AI request failed (${response.status}).`).slice(0,300));
  if(typeof data.answer!=='string'||!data.answer.trim())throw new Error('The AI returned no answer.');
  return {text:data.answer.slice(0,30000),model:String(data.model||'Gemini')};
}
