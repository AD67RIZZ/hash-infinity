import { AI_CONFIG } from './config.js';
import { askOnlineAI, makeWorkspaceContext, isSecureEndpoint } from './ai.js';
import { VERSION, STORAGE_KEY, DEFAULT_STATE, clone, escapeHtml as E, newId, validHttpUrl, safeImport, formatMoney as money, todayKey, calc, UNIT_GROUPS, convert, humanNum, portfolio, randomPassword, monthExpenses, daysBetween, secureRandomIndex } from './core.js';

const TOOLS = [
  {id:'assistant',name:'Infinity Assist',group:'Intelligence',icon:'sparkles',desc:'Real Gemini chat when a secure AI gateway is connected; local tool help offline.',tag:'AI-ready'},
  {id:'tasks',name:'Tasks',group:'Organize',icon:'check-square',desc:'Capture priorities, deadlines and the little things.'},
  {id:'notes',name:'Notes',group:'Organize',icon:'file-text',desc:'A calm home for thoughts and long-form notes.'},
  {id:'planner',name:'Planner',group:'Organize',icon:'calendar',desc:'Keep plans and important dates in one place.'},
  {id:'calculator',name:'Calculator',group:'Utilities',icon:'calculator',desc:'Fast arithmetic with a real expression parser.'},
  {id:'converter',name:'Unit converter',group:'Utilities',icon:'repeat',desc:'Length, mass, speed, data and temperature.'},
  {id:'finance',name:'Budget tracker',group:'Money',icon:'wallet',desc:'Log expenses and view monthly spending.'},
  {id:'markets',name:'Paper portfolio',group:'Money',icon:'trending-up',desc:'Learn with pretend trades and manually entered prices.',tag:'Simulation only'},
  {id:'habits',name:'Habit tracker',group:'Wellness',icon:'activity',desc:'Build consistency, one day at a time.'},
  {id:'study',name:'Flashcards',group:'Learning',icon:'graduation-cap',desc:'Create study cards and reveal answers.'},
  {id:'focus',name:'Focus timer',group:'Wellness',icon:'timer',desc:'Stay in flow with flexible work sessions.'},
  {id:'password',name:'Password maker',group:'Utilities',icon:'shield',desc:'Generate strong passwords with secure randomness.'},
  {id:'writing',name:'Writing studio',group:'Create',icon:'type',desc:'Draft, count and transform text instantly.'},
  {id:'json',name:'JSON studio',group:'Create',icon:'braces',desc:'Check and format JSON locally.'},
  {id:'code',name:'HTML playground',group:'Create',icon:'code',desc:'Experiment with HTML, CSS and JavaScript safely.'},
  {id:'bookmarks',name:'Bookmarks',group:'Organize',icon:'bookmark',desc:'Collect websites and useful resources.'},
  {id:'goals',name:'Goal tracker',group:'Organize',icon:'activity',desc:'Set measurable milestones and track progress.'},
  {id:'datecalc',name:'Date calculator',group:'Utilities',icon:'calendar',desc:'Count days between dates and plan ahead.'},
  {id:'textlab',name:'Text lab',group:'Create',icon:'type',desc:'Analyze, clean and transform text in one place.'},
  {id:'picker',name:'Decision picker',group:'Utilities',icon:'repeat',desc:'Fair random choices from your own list.'}
];
const ICONS={
 home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
 grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
 sparkles:'<path d="m12 3 1.9 6.1L20 11l-6.1 1.9L12 19l-1.9-6.1L4 11l6.1-1.9z"/><path d="m19 17 .7 1.8L21.5 19.5l-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7z"/>',
 'check-square':'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="m7 12 3 3 7-7"/>',
 'file-text':'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
 calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
 calculator:'<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M7 7h10M8 12h2M14 12h2M8 16h2M14 16h2"/>',
 repeat:'<path d="M3 8h13l-3-3m3 3-3 3M21 16H8l3-3m-3 3 3 3"/>',
 wallet:'<rect x="3" y="5" width="18" height="15" rx="3"/><path d="M3 9h18M16 14h2"/>',
 'trending-up':'<path d="m3 17 6-6 4 4 8-8M15 7h6v6"/>',
 activity:'<path d="M3 12h4l3-8 4 16 3-8h4"/>',
 'graduation-cap':'<path d="m2 10 10-5 10 5-10 5zM6 12v5c4 3 8 3 12 0v-5M22 10v7"/>',
 timer:'<circle cx="12" cy="13" r="9"/><path d="M12 8v5l3 2M9 2h6"/>',
 shield:'<path d="m12 2 8 3v6c0 5-3 8-8 11-5-3-8-6-8-11V5z"/><path d="m9 12 2 2 4-4"/>',
 type:'<path d="M4 7V4h16v3M12 4v16M8 20h8"/>',
 braces:'<path d="M9 3H7a2 2 0 0 0-2 2v5l-2 2 2 2v5a2 2 0 0 0 2 2h2M15 3h2a2 2 0 0 1 2 2v5l2 2-2 2v5a2 2 0 0 1-2 2h-2"/>',
 code:'<path d="m8 6-6 6 6 6M16 6l6 6-6 6M14 3l-4 18"/>',
 bookmark:'<path d="M5 3h14v18l-7-5-7 5z"/>',
 settings:'<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1l2-1.5-2-3.5-2.3 1a7 7 0 0 0-1.7-1L14.5 3h-4L10 6a7 7 0 0 0-1.7 1L6 6l-2 3.5L6 11a7 7 0 0 0 0 2l-2 1.5L6 18l2.3-1a7 7 0 0 0 1.7 1l.5 3h4l.5-3a7 7 0 0 0 1.7-1l2.3 1 2-3.5L19 13a7 7 0 0 0 0-1z"/>',
 search:'<circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 'arrow-right':'<path d="M5 12h14m-6-6 6 6-6 6"/>',
 trash:'<path d="M4 7h16M10 4h4M6 7l1 14h10l1-14M10 11v6M14 11v6"/>',
 check:'<path d="m5 12 5 5L20 7"/>',
 download:'<path d="M12 3v12m-4-4 4 4 4-4M4 18v3h16v-3"/>',
 upload:'<path d="M12 18V6m-4 4 4-4 4 4M4 3v3M20 3v3M4 18v3h16v-3"/>',
 external:'<path d="M14 4h6v6M20 4l-9 9M20 13v7H4V4h7"/>',
 menu:'<path d="M4 7h16M4 12h16M4 17h16"/>',
 x:'<path d="M5 5l14 14M19 5 5 19"/>',
 star:'<path d="m12 2 3 7 7 .5-5.5 5 1.6 7.5-6.1-4-6.1 4L7.5 14.5 2 9.5 9 9z"/>',
 copy:'<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
 sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4 12H2M22 12h-2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4m0-14.2-1.4 1.4M6.3 17.7l-1.4 1.4"/>',
 moon:'<path d="M21 13a9 9 0 1 1-10-10 8 8 0 0 0 10 10z"/>',
 'chevron-down':'<path d="m6 9 6 6 6-6"/>',
 'more-horizontal':'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>'
};
const ico=(name,size=20)=>`<svg class="ico" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]??ICONS.grid}</svg>`;
const logo='./assets/hash-infinity-original.png';
const root=document.getElementById('app');
let data;
try{data=safeImport(localStorage.getItem(STORAGE_KEY) || clone(DEFAULT_STATE));}catch{data=clone(DEFAULT_STATE);}
let view='home', drawerOpen=false, searchOpen=false, searchTerm='', filterGroup='All', selectedNote=null, selectedCard=0, revealCard=false, timerRunning=false, timerRemaining=25*60, timerDuration=25*60, timerEndAt=0, calcInput='0', convertType='length', convertFrom='m', convertTo='km', convertVal='1', writingVal='', jsonVal='{"hello":"Infinity"}', jsonOutput='', codeVal='<!doctype html>\n<html><body style="font: 24px system-ui; padding: 30px; color: #12213a">\n<h1>Hello, Infinity!</h1>\n<p>Edit this HTML and press Run.</p>\n</body></html>', passwordValue='', drawerFilter='';
const onlineAI=isSecureEndpoint(AI_CONFIG.endpoint) && !!AI_CONFIG.turnstileSiteKey;
let chatMode='general',shareWorkspace=false,chatBusy=false,chatAbort=null,turnstileWidget=null,turnstilePromise=null;
let dateStart=todayKey(),dateEnd=todayKey(),dateResult='',textLabValue='',pickerValue='',pickerResult='';
let chat=Array.isArray(data.chats)?data.chats:[];
const save=()=>{try{localStorage.setItem(STORAGE_KEY,JSON.stringify(data));}catch{toast('Storage is full or unavailable. Export your data.','error');}};
function toast(message,kind='success'){
 let el=document.querySelector('.toast');if(!el){el=document.createElement('div');el.className='toast';el.setAttribute('role','status');document.body.appendChild(el);}
 el.textContent=message;el.dataset.kind=kind;el.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove('show'),3500);
}
function navButton(id,label,icon,cls=''){return `<button class="nav-item ${view===id?'active':''} ${cls}" data-nav="${id}">${ico(icon,19)}<span>${E(label)}</span></button>`;}
function brand(){return `<div class="brand-mark"><img src="${logo}" alt="#Infinity brand icon" /></div><div class="brand-type"><strong>#Infinity</strong><small>Everything, in one space.</small></div>`;}
function shell(){
 root.innerHTML=`<div class="shell ${data.profile.theme==='light'?'light':''}">
 <aside class="sidebar ${drawerOpen?'open':''}" aria-label="Main navigation">
 <div class="brand">${brand()}<button class="icon-button mobile-close" data-action="drawer-close" aria-label="Close menu">${ico('x')}</button></div>
 <div class="sidebar-scroll"><p class="nav-label">WORKSPACE</p>
 ${navButton('home','Home','home')}${navButton('explore','Explore all tools','grid')}${navButton('assistant','Infinity Assist','sparkles')}
 <p class="nav-label nav-spaced">YOUR FAVORITES</p>
 ${data.profile.pinned.filter(id=>TOOLS.some(t=>t.id===id)).slice(0,7).map(id=>{const t=TOOLS.find(x=>x.id===id);return navButton(id,t.name,t.icon);}).join('')}
 <p class="nav-label nav-spaced">ACCOUNT</p>${navButton('settings','Settings','settings')}
 </div><div class="sidebar-foot"><div class="foot-orb">∞</div><div><strong>Build without limits</strong><p>Free local workspace</p></div></div></aside>
 <div class="main-shell"><header class="topbar"><div class="topbar-left"><button class="icon-button menu-open" data-action="drawer-open" aria-label="Open menu">${ico('menu')}</button><div class="breadcrumbs"><span>Workspace</span><b>/</b><strong>${view==='home'?'Overview':view==='explore'?'Discover':view==='settings'?'Settings':E(TOOLS.find(t=>t.id===view)?.name||'Home')}</strong></div></div>
 <div class="topbar-right"><button class="search-trigger" data-action="open-search">${ico('search',18)}<span>Search anything…</span><kbd>⌘ K</kbd></button><button class="icon-button theme-button" data-action="theme" aria-label="Toggle theme">${ico(data.profile.theme==='light'?'moon':'sun',19)}</button><button class="profile-bubble" data-nav="settings" title="Your workspace">${E(data.profile.name.trim().charAt(0).toUpperCase()||'I')}</button></div></header>
 <main class="page" id="page"></main>
 <nav class="bottom-nav" aria-label="Mobile quick navigation">${navButton('home','Home','home')}${navButton('explore','Discover','grid')}${navButton('assistant','Assist','sparkles')}${navButton('tasks','Tasks','check-square')}${navButton('settings','Settings','settings')}</nav>
 </div>${drawerOpen?'<button class="drawer-backdrop" data-action="drawer-close" aria-label="Dismiss navigation"></button>':''}</div>`;
 renderPage();if(searchOpen)renderSearch();
}
function heading(eyebrow,title,subtitle,right='') {return `<div class="section-heading"><div><p class="eyebrow">${E(eyebrow)}</p><h1>${E(title)}</h1><p class="section-subtitle">${E(subtitle)}</p></div>${right?`<div class="heading-action">${right}</div>`:''}</div>`;}
function panel(title,body,actions='',cls=''){return `<section class="panel ${cls}"><div class="panel-title"><h2>${E(title)}</h2>${actions}</div>${body}</section>`;}
function toolCard(tool,small=false){return `<button class="tool-card ${small?'compact':''}" data-nav="${tool.id}"><span class="tool-icon">${ico(tool.icon,24)}</span><span class="tool-detail"><strong>${E(tool.name)}</strong><small>${E(tool.desc)}</small></span><span class="tool-open">${ico('arrow-right',18)}</span></button>`;}
function statCard(label,value,hint,icon){return `<div class="stat-card"><span class="stat-icon">${ico(icon,20)}</span><p>${E(label)}</p><strong>${E(String(value))}</strong><small>${E(hint)}</small></div>`;}
function empty(title,detail,icon='grid'){return `<div class="empty-state"><span class="empty-icon">${ico(icon,26)}</span><strong>${E(title)}</strong><p>${E(detail)}</p></div>`;}
function button(text,action,cls='btn-primary',icon='plus'){return `<button class="btn ${cls}" data-action="${action}">${ico(icon,17)}${E(text)}</button>`;}
function renderPage(){const target=document.getElementById('page');if(!target)return;
 const views={home:homePage,explore:explorePage,assistant:assistantPage,tasks:tasksPage,notes:notesPage,planner:plannerPage,calculator:calculatorPage,converter:converterPage,finance:financePage,markets:marketPage,habits:habitsPage,study:studyPage,focus:focusPage,password:passwordPage,writing:writingPage,json:jsonPage,code:codePage,bookmarks:bookmarksPage,goals:goalsPage,datecalc:datecalcPage,textlab:textLabPage,picker:pickerPage,settings:settingsPage};
 target.innerHTML=(views[view]||homePage)(); target.scrollTop=0;
 if(view==='focus')updateTimerDisplay();if(view==='code')updateCodeFrame(false);if(view==='assistant')queueMicrotask(setupTurnstile);
}
function navigate(id){if(!['home','explore','settings',...TOOLS.map(t=>t.id)].includes(id))return;view=id;drawerOpen=false;searchOpen=false;searchTerm='';shell();window.scrollTo?.(0,0);}
function homePage(){const pending=data.tasks.filter(t=>!t.done), recent=[...data.notes].sort((a,b)=>(b.updated||'').localeCompare(a.updated||'')).slice(0,3);
 return `<section class="hero"><div class="hero-copy"><span class="hero-pill"><span class="pulse-dot"></span> YOUR DAILY UNIVERSE</span><h1>More possibilities.<br><em>One place.</em></h1><p>Your ideas, plans, tools and projects—beautifully organized in your own space. No clutter, no switching apps for the basics.</p><div class="hero-actions">${button('Explore all tools','go-explore','btn-gold','grid')}<button class="btn btn-outline-light" data-nav="assistant">${ico('sparkles',17)}Open Assist</button></div></div><div class="hero-art" aria-hidden="true"><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><div class="hero-logo"><img src="${logo}" alt="" /></div><div class="float-chip chip-a">${ico('check-square',15)}Plan</div><div class="float-chip chip-b">${ico('sparkles',15)}Create</div><div class="float-chip chip-c">${ico('trending-up',15)}Track</div></div></section>
 <div class="welcome-strip"><div><p class="eyebrow">GOOD TO HAVE YOU HERE</p><h2>Welcome, ${E(data.profile.name)} <span class="wave">✦</span></h2><p>What would you like to accomplish today?</p></div><span class="date-chip">${E(new Date().toLocaleDateString('en-AE',{weekday:'short',month:'short',day:'numeric'}))}</span></div>
 <div class="stats-grid">${statCard('To-dos left',pending.length,'Things waiting for you','check-square')}${statCard('Your notes',data.notes.length,'Ideas saved locally','file-text')}${statCard('Habits',data.habits.length,'Routines you track','activity')}${statCard('Tools ready',TOOLS.length,'And more on the way','grid')}</div>
 <div class="content-grid"><div>${panel('Jump back in',`<div class="quick-grid">${['assistant','tasks','notes','calculator','study','finance'].map(id=>toolCard(TOOLS.find(t=>t.id===id),true)).join('')}</div>`,`<button class="text-link" data-nav="explore">See all ${ico('arrow-right',15)}</button>`)}</div>
 <div>${panel('Today’s focus',pending.length?`<div class="mini-tasks">${pending.slice(0,4).map(t=>`<button class="mini-task" data-nav="tasks"><span class="mini-ring"></span><span>${E(t.title)}</span>${ico('arrow-right',15)}</button>`).join('')}</div>`:empty('A fresh start','Add a task to see it here.','check-square'),`<button class="text-link" data-nav="tasks">Manage tasks ${ico('arrow-right',15)}</button>`)}</div></div>
 <div class="content-grid bottom-content"><div>${panel('Just for you',`<div class="feature-promo"><div class="promo-symbol">${ico('graduation-cap',31)}</div><div><h3>Build your knowledge</h3><p>Make flashcards from your lessons and keep learning at your pace.</p><button class="text-link" data-nav="study">Open flashcards ${ico('arrow-right',16)}</button></div></div>`)}</div><div>${panel('Recent notes',recent.length?`<div class="recent-items">${recent.map(n=>`<button data-open-note="${E(n.id)}"><strong>${E(n.title||'Untitled note')}</strong><small>${E((n.body||'').slice(0,72)||'No content yet')}</small></button>`).join('')}</div>`:empty('Nothing here yet','Your latest notes will appear here.','file-text'),`<button class="text-link" data-nav="notes">Open notes ${ico('arrow-right',15)}</button>`)}</div></div>
 <div class="footer-note">#Infinity • Your data lives on this device unless you export it. Not all services are included in the offline edition.</div>`;
}
function explorePage(){const groups=['All',...new Set(TOOLS.map(t=>t.group))];const matches=TOOLS.filter(t=>(filterGroup==='All'||t.group===filterGroup)&&`${t.name} ${t.desc} ${t.group}`.toLowerCase().includes(searchTerm.toLowerCase()));
 return `${heading('DISCOVER','A tool for every idea.','Explore your Infinity workspace. Every tool here is real and usable.')}
 <div class="discover-search">${ico('search')}<input id="explore-query" aria-label="Search tools" placeholder="Search tools, features, or what you need…" value="${E(searchTerm)}" autocomplete="off"/></div>
 <div class="filter-row">${groups.map(g=>`<button class="filter-pill ${filterGroup===g?'on':''}" data-filter="${E(g)}">${E(g)}</button>`).join('')}</div>
 <div class="discover-grid">${matches.map(t=>`<article class="discover-card"><div class="discover-top"><span class="tool-icon large">${ico(t.icon,26)}</span><button class="pin-button ${data.profile.pinned.includes(t.id)?'pinned':''}" data-pin="${t.id}" aria-label="${data.profile.pinned.includes(t.id)?'Remove favorite':'Add favorite'}">${ico('star',17)}</button></div><p class="tool-group">${E(t.group)}${t.tag?` · ${E(t.tag)}`:''}</p><h3>${E(t.name)}</h3><p>${E(t.desc)}</p><button class="open-tool-btn" data-nav="${t.id}">Open tool ${ico('arrow-right',18)}</button></article>`).join('')}</div>${!matches.length?empty('No results','Try a different keyword or category.','search'):''}`;
}
function assistantPage(){
 const status=onlineAI?'Gemini gateway configured · connection tested when you send':'Offline guidance · Gemini gateway not yet connected';
 const intro=onlineAI?'I’m connected to a Gemini-compatible service when the gateway is available. Ask for explanations, drafting, code or planning.':'I can find workspace tools and calculate expressions offline. A real AI model needs the hosted gateway to be configured; I won’t invent answers.';
 return `${heading('INTELLIGENCE','Infinity Assist','A multi-turn chat interface designed for a securely hosted Gemini model.')}<div class="assist-layout"><section class="panel assist-panel">
 <div class="assistant-header"><span class="assist-avatar">${ico('sparkles',24)}</span><div><strong>Infinity Assist</strong><small><span class="live-dot"></span> ${E(status)}</small></div><span class="assist-pill">${onlineAI?'Gemini ready':'Local mode'}</span></div>
 <div class="assist-toolbar"><label class="small-control">Assistant mode <select id="ai-mode">${[['general','Everyday'],['study','Study tutor'],['write','Writing'],['code','Coding'],['plan','Planning']].map(([k,v])=>`<option value="${k}" ${chatMode===k?'selected':''}>${v}</option>`).join('')}</select></label><div class="assist-toolbar-actions"><button data-action="copy-chat" class="tool-text-button">${ico('copy',14)} Copy chat</button><button data-action="clear-chat" class="tool-text-button">${ico('trash',14)} Clear</button></div></div>
 <div class="chat-messages" id="messages" aria-live="polite"><div class="chat-msg bot"><span class="chat-avatar">${ico('sparkles',16)}</span><div class="chat-bubble"><strong>Welcome to #Infinity.</strong><p>${E(intro)}</p></div></div>${chat.map(m=>`<div class="chat-msg ${m.role==='user'?'user':'bot'}">${m.role==='bot'?`<span class="chat-avatar">${ico('sparkles',16)}</span>`:''}<div class="chat-bubble"><p>${E(m.text)}</p>${m.link?`<button data-nav="${E(m.link)}" class="text-link">Open ${E(TOOLS.find(t=>t.id===m.link)?.name||'tool')} ${ico('arrow-right',15)}</button>`:''}</div></div>`).join('')}${chatBusy?`<div class="chat-msg bot"><span class="chat-avatar">${ico('sparkles',16)}</span><div class="chat-bubble thinking">Thinking…</div></div>`:''}</div>
 ${chat.some(m=>m.role==='bot')?`<div class="ai-actions"><button data-action="save-last-ai" class="tool-text-button">${ico('file-text',15)} Save latest reply to Notes</button></div>`:''}
 <div class="chat-suggestions">${(onlineAI?['Explain a complex idea','Help me write something','Review this code','Plan my week']:['Open my tasks','Calculate (144 / 12) * 3','Find my flashcards','What tools exist?']).map(q=>`<button data-ask="${E(q)}" ${chatBusy?'disabled':''}>${E(q)}</button>`).join('')}</div>
 ${onlineAI?`<div class="assist-privacy"><label><input id="ai-context" type="checkbox" ${shareWorkspace?'checked':''}/> Include my open task titles and note titles in this next AI request</label><small>No note contents, financial records or passwords are shared.</small></div><div class="turnstile-container" id="turnstile-widget"></div>`:''}
 <form id="chat-form" class="chat-form"><textarea name="message" rows="2" maxlength="5000" autocomplete="off" required placeholder="Ask #Infinity anything…" aria-label="Message Infinity Assist" ${chatBusy?'disabled':''}></textarea>${chatBusy?`<button type="button" data-action="cancel-chat" class="btn-icon-send" aria-label="Stop generating">${ico('x',19)}</button>`:`<button type="submit" class="btn-icon-send" aria-label="Send message">${ico('arrow-right',19)}</button>`}</form>
 </section><aside class="assist-aside">${panel('Designed for real work',`<div class="capabilities"><div>${ico('file-text',19)}Multi-turn conversations</div><div>${ico('graduation-cap',19)}Study and writing modes</div><div>${ico('code',19)}Code explanations</div><div>${ico('shield',19)}Opt-in context only</div><div>${ico('download',19)}Local chat history and backup</div></div>`)}<div class="info-card"><strong>${onlineAI?'Secure by design':'Live AI setup pending'}</strong><p>${onlineAI?'The model key belongs only in a protected server. Requests require verification and are limited to protect free-tier quotas.':'The website still runs offline. To enable free-tier Gemini for all users, publish and configure the included protected Cloudflare Worker. The website never contains a shared API key.'}</p></div></aside></div>`;
}
async function setupTurnstile(){
 if(view!=='assistant'||!onlineAI)return;
 const box=document.getElementById('turnstile-widget');if(!box)return;
 try{
  if(!turnstilePromise)turnstilePromise=new Promise((resolve,reject)=>{
   if(window.turnstile){resolve(window.turnstile);return;}
   const s=document.createElement('script');s.src='https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';s.async=true;s.defer=true;s.onload=()=>resolve(window.turnstile);s.onerror=()=>reject(new Error('Verification could not load.'));document.head.appendChild(s);
  });
  const ts=await turnstilePromise;
  if(!box.isConnected)return;
  if(turnstileWidget!==null){try{ts.remove(turnstileWidget);}catch{}turnstileWidget=null;}
  turnstileWidget=ts.render(box,{sitekey:AI_CONFIG.turnstileSiteKey,theme:'auto'});
 }catch{box.textContent='Human verification is unavailable. AI messages cannot be sent.';}
}
function localReply(q){
 const s=q.toLowerCase().trim(); const basic=s.replace(/^(what is|calculate|compute|solve)\s+/,'').replace(/[?=]\s*$/,'').trim();
 if(/^[\d.()+\-*/%^\s×÷]+$/.test(basic)&&/\d/.test(basic)){try{return {text:`${basic} = ${humanNum(calc(basic))}`};}catch{return{text:'I could not calculate that expression. Try something like (12 + 8) × 3.'};}}
 if(/what can you|help|features|everything|do you do/.test(s))return {text:'I can calculate expressions, guide you to your tools and explain the offline workspace. Try asking for notes, tasks, budgeting, flashcards, coding, a password, or a timer. Complex reasoning and general knowledge need an external AI model.'};
 const aliases={assistant:['ai','assistant','chat'],tasks:['task','to-do','todo','checklist'],notes:['note','write note','journal'],planner:['plan','event','calendar','schedule'],calculator:['math','calculate','calculator'],converter:['convert','unit','temperature','kilometer'],finance:['budget','expense','spend','money'],markets:['paper','trade','portfolio','stock'],habits:['habit','routine'],study:['flashcard','study','memorize','learn'],focus:['focus','pomodoro','timer'],password:['password','secure random'],writing:['writing','word count','text'],json:['json'],code:['html','code','playground'],bookmarks:['bookmark','link']};
 for(const [id,words] of Object.entries(aliases)){if(words.some(w=>s.includes(w))){const t=TOOLS.find(x=>x.id===id);return {text:`I found ${t.name}. ${t.desc} Open it using the button below.`,link:id};}}
 return {text:'I am a local, tool-focused helper, not a connected language model. I can handle arithmetic and find a workspace tool. For open-ended AI questions, a developer must integrate a secure model service.'};
}
function tasksPage(){const list=[...data.tasks].sort((a,b)=>Number(a.done)-Number(b.done)||(a.due||'9999').localeCompare(b.due||'9999'));return `${heading('ORGANIZE','Make progress visible.','Capture what matters and check it off.',button('New task','focus-task','btn-primary','plus'))}
 <div class="two-col"><div>${panel('My tasks',`<div class="task-summary"><span>${data.tasks.filter(t=>t.done).length} done</span><span>${data.tasks.filter(t=>!t.done).length} remaining</span></div><div class="progress-track"><span style="width:${data.tasks.length?Math.round(data.tasks.filter(t=>t.done).length/data.tasks.length*100):0}%"></span></div>${list.length?`<div class="task-list">${list.map(t=>`<div class="task-item ${t.done?'completed':''}"><button class="task-checkbox" data-toggle-task="${E(t.id)}" aria-label="${t.done?'Mark not done':'Mark done'}">${t.done?ico('check',15):''}</button><div class="task-info"><strong>${E(t.title)}</strong><small>${t.due?`Due ${E(t.due)} • `:''}<span class="priority ${E(t.priority||'normal')}">${E(t.priority||'normal')}</span></small></div><button class="icon-button danger-on-hover" data-delete="task:${E(t.id)}" aria-label="Delete task">${ico('trash',17)}</button></div>`).join('')}</div>`:empty('All clear','Your next step begins with one task.','check-square')}`)}</div>
 <div>${panel('Add a task',`<form id="task-form" class="form-stack"><label>What needs doing?<input id="task-title" name="title" required maxlength="160" placeholder="e.g. Finish the presentation"/></label><label>Due date (optional)<input type="date" name="due" /></label><label>Priority<select name="priority"><option value="normal">Normal</option><option value="high">High</option><option value="low">Low</option></select></label><button class="btn btn-primary" type="submit">${ico('plus',17)}Add task</button></form>`)}</div></div>`;}
function notesPage(){if(!selectedNote&&data.notes.length)selectedNote=data.notes[0].id;const current=data.notes.find(n=>n.id===selectedNote);
 return `${heading('ORGANIZE','A space for your thoughts.','Capture ideas without distractions.',button('New note','new-note','btn-primary','plus'))}
 <div class="notes-layout"><div class="notes-list panel"><div class="panel-title"><h2>All notes</h2><span class="count-pill">${data.notes.length}</span></div>${data.notes.length?data.notes.map(n=>`<button class="note-link ${n.id===selectedNote?'selected':''}" data-open-note="${E(n.id)}"><strong>${E(n.title||'Untitled note')}</strong><small>${E((n.body||'').slice(0,68)||'Empty note')}</small></button>`).join(''):empty('No notes yet','Choose New note to begin.','file-text')}</div>
 <div class="panel note-editor">${current?`<form id="note-form"><input type="hidden" name="id" value="${E(current.id)}"/><input class="note-title-input" name="title" aria-label="Note title" maxlength="200" value="${E(current.title||'')}" placeholder="Untitled note"/><p class="note-meta">Updated ${E(new Date(current.updated||Date.now()).toLocaleString())}</p><textarea name="body" class="note-body-input" aria-label="Note contents" maxlength="30000" placeholder="Start writing something meaningful…">${E(current.body||'')}</textarea><div class="note-buttons"><button type="submit" class="btn btn-primary">${ico('check',17)}Save note</button><button type="button" class="btn btn-subtle danger" data-delete="note:${E(current.id)}">${ico('trash',17)}Delete</button></div></form>`:empty('Select a note','Your editor will appear here.','file-text')}</div></div>`;
}
function plannerPage(){const plans=[...data.plans].sort((a,b)=>(a.date||'').localeCompare(b.date||''));return `${heading('ORGANIZE','Plan with clarity.','A simple schedule of events and moments worth remembering.')}
 <div class="two-col"><div>${panel('Upcoming plans',plans.length?`<div class="plan-list">${plans.map(p=>`<div class="plan-row"><div class="plan-day"><strong>${E(String(p.date||'').slice(-2))}</strong><small>${E(new Date(`${p.date}T12:00`).toLocaleDateString('en-AE',{month:'short'}))}</small></div><div><strong>${E(p.title)}</strong><small>${E(p.date)} ${p.time?`• ${E(p.time)}`:''}</small></div><button class="icon-button danger-on-hover" data-delete="plan:${E(p.id)}" aria-label="Remove plan">${ico('trash',17)}</button></div>`).join('')}</div>`:empty('A clear calendar','Add your first plan on the right.','calendar'))}</div><div>${panel('Create an event',`<form class="form-stack" id="plan-form"><label>Event name<input name="title" maxlength="180" required placeholder="Meeting, exam, birthday…"/></label><label>Date<input name="date" type="date" required value="${todayKey()}"/></label><label>Time (optional)<input name="time" type="time"/></label><button type="submit" class="btn btn-primary">${ico('plus',17)}Add event</button></form>`)}</div></div>`;}
function calculatorPage(){const buttons=['C','(',')','÷','7','8','9','×','4','5','6','−','1','2','3','+','0','.','%','='];return `${heading('UTILITIES','Calculator','Straightforward, fast and reliable arithmetic.')}
 <div class="calculator-wrap"><div class="calculator-body"><div class="calc-brand"><span>${ico('calculator',17)} INFINITY CALC</span><span>LOCAL • INSTANT</span></div><div class="calc-screen" id="calc-screen">${E(calcInput)}</div><div class="calc-keypad">${buttons.map(b=>`<button class="calc-key ${b==='='?'equals':'+−×÷'.includes(b)?'operator':b==='C'?'clear':''}" data-calc="${E(b)}">${E(b)}</button>`).join('')}</div></div><div class="calc-side"><h3>Built for the little calculations.</h3><p>Enter expressions with your keyboard or the keypad. Supports brackets, decimals, percentages as a remainder operator, and powers with ^.</p><div class="calc-tip"><strong>Try</strong><code>(150 + 50) / 4</code><button class="text-link" data-calc-example="(150+50)/4">Use example ${ico('arrow-right',15)}</button></div></div></div>`;}
function converterPage(){const options=Object.keys(UNIT_GROUPS[convertType]);if(!options.includes(convertFrom))convertFrom=options[0];if(!options.includes(convertTo))convertTo=options[1];let out;try{out=humanNum(convert(convertVal,convertType,convertFrom,convertTo));}catch{out='Enter a number';}
 return `${heading('UTILITIES','Unit converter','Useful conversions without an internet connection.')}
 <section class="panel converter-wrap"><div class="converter-types">${Object.keys(UNIT_GROUPS).map(t=>`<button data-convert-group="${t}" class="filter-pill ${t===convertType?'on':''}">${E(t[0].toUpperCase()+t.slice(1))}</button>`).join('')}</div><div class="convert-fields"><label><span>FROM</span><input id="convert-input" type="number" step="any" value="${E(convertVal)}"/><select id="convert-from">${options.map(o=>`<option ${o===convertFrom?'selected':''}>${E(o)}</option>`).join('')}</select></label><button class="swap-button" data-action="swap-units" aria-label="Swap units">${ico('repeat',19)}</button><label><span>TO</span><output id="convert-result">${E(out)}</output><select id="convert-to">${options.map(o=>`<option ${o===convertTo?'selected':''}>${E(o)}</option>`).join('')}</select></label></div><p class="converter-note">Calculated on your device. Currency conversion requires live exchange rates and is not included.</p></section>`;}
function financePage(){const total=monthExpenses(data.expenses);const categoryTotals={};for(const x of data.expenses.filter(x=>String(x.date||'').startsWith(todayKey().slice(0,7))))categoryTotals[x.category]=(categoryTotals[x.category]||0)+Number(x.amount);const max=Math.max(1,...Object.values(categoryTotals));
 return `${heading('MONEY','Know where it goes.','Track personal spending in a calm, private place.')}
 <div class="money-banner"><span class="money-icon">${ico('wallet',24)}</span><div><span>SPENT THIS MONTH</span><strong>${money(total)}</strong><small>${data.expenses.filter(x=>String(x.date||'').startsWith(todayKey().slice(0,7))).length} transactions</small></div></div>
 <div class="two-col"><div>${panel('Recent expenses',data.expenses.length?`<div class="transactions">${[...data.expenses].reverse().slice(0,30).map(e=>`<div class="transaction"><span class="transaction-emoji">${ico('wallet',19)}</span><div><strong>${E(e.title)}</strong><small>${E(e.category)} · ${E(e.date)}</small></div><b>−${money(e.amount)}</b><button class="icon-button danger-on-hover" data-delete="expense:${E(e.id)}" aria-label="Delete expense">${ico('trash',16)}</button></div>`).join('')}</div>`:empty('No expenses yet','Add a purchase to start tracking.','wallet'))}</div>
 <div>${panel('Add expense',`<form class="form-stack" id="expense-form"><label>What was it?<input name="title" maxlength="120" required placeholder="Coffee, groceries…"/></label><label>Amount (AED)<input type="number" name="amount" min="0.01" max="1000000000" step="0.01" required placeholder="0.00"/></label><label>Category<select name="category">${['Food','Shopping','Transport','Bills','Health','Education','Other'].map(c=>`<option>${c}</option>`).join('')}</select></label><label>Date<input name="date" type="date" value="${todayKey()}" required/></label><button type="submit" class="btn btn-primary">${ico('plus',17)}Save expense</button></form>`)}</div></div>
 ${panel('This month by category',Object.keys(categoryTotals).length?`<div class="bars">${Object.entries(categoryTotals).sort((a,b)=>b[1]-a[1]).map(([name,amount])=>`<div class="bar-line"><div><span>${E(name)}</span><strong>${money(amount)}</strong></div><div class="bar-track"><span style="width:${Math.max(1,amount/max*100)}%"></span></div></div>`).join('')}</div>`:empty('Nothing to chart','Category breakdown appears after your first entry.','trending-up'))}`;
}
function marketPage(){const pf=portfolio(data.trades,data.quotes);const tickers=pf.positions;return `${heading('MONEY','Practice, not pressure.','A paper portfolio using pretend money and prices you enter manually.')}
 <div class="disclaimer">${ico('shield',19)} <span><strong>Simulation only.</strong> No real trades, brokerage connection, live prices, or investment recommendations.</span></div>
 <div class="stats-grid money-stats">${statCard('Paper equity',money(pf.equity),'Starting cash: AED 10,000','wallet')}${statCard('Paper cash',money(pf.cash),'Uninvested simulation balance','calculator')}${statCard('Holdings',tickers.length,'Practice positions','trending-up')}${statCard('Paper change',money(pf.equity-10000),'Based on your manual marks','activity')}</div>
 <div class="two-col"><div>${panel('Paper positions',tickers.length?`<div class="position-list">${tickers.map(p=>`<div class="position"><div><strong>${E(p.ticker)}</strong><small>${humanNum(p.qty)} units · avg ${money(p.average)}</small></div><div><strong>${money(p.qty*p.mark)}</strong><small>Marked at ${money(p.mark)}</small></div></div>`).join('')}</div>`:empty('No holdings','Use the form to try a paper transaction.','trending-up') + `<p class="muted-small">Price marks are stored locally. Actual markets may differ.</p>`)}</div>
 <div>${panel('Place a pretend trade',`<form class="form-stack" id="trade-form"><label>Symbol<input name="ticker" pattern="[A-Za-z0-9.\-]{1,12}" maxlength="12" required placeholder="e.g. DEMO" autocapitalize="characters"/></label><div class="form-row"><label>Quantity<input name="qty" type="number" min="0.000001" step="any" required value="1"/></label><label>Manual price (AED)<input name="price" type="number" min="0.000001" step="any" required placeholder="100"/></label></div><label>Action<select name="side"><option value="buy">Paper buy</option><option value="sell">Paper sell</option></select></label><button type="submit" class="btn btn-primary">${ico('plus',17)}Record simulation</button></form><p class="muted-small">Price you enter also becomes the latest manual valuation for that symbol.</p>`)}</div></div>
 ${panel('Trade history',data.trades.length?`<div class="transactions">${[...data.trades].reverse().slice(0,20).map(t=>`<div class="transaction"><span class="transaction-emoji">${ico('trending-up',19)}</span><div><strong>${E(t.side?.toUpperCase())} ${E(t.ticker)}</strong><small>${humanNum(Number(t.qty))} units · ${E(t.date||'')}</small></div><b>${money(Number(t.price)*Number(t.qty))}</b></div>`).join('')}</div>`:empty('No practice history','Your example trades appear here.','trending-up'))}`;
}
function habitsPage(){const today=todayKey();return `${heading('WELLNESS','Small steps, every day.','Build habits at your own pace—without streak pressure.')}
 <div class="two-col"><div>${panel('My habits',data.habits.length?`<div class="habit-list">${data.habits.map(h=>{const completed=(h.days||'').split('|').filter(Boolean);return `<div class="habit-row"><button class="habit-check ${completed.includes(today)?'complete':''}" data-toggle-habit="${E(h.id)}" aria-label="${completed.includes(today)?'Undo today':'Complete today'}">${ico('check',18)}</button><div><strong>${E(h.title)}</strong><small>${completed.length} total days · ${completed.includes(today)?'Done today':'Ready today'}</small></div><button class="icon-button danger-on-hover" data-delete="habit:${E(h.id)}" aria-label="Delete habit">${ico('trash',16)}</button></div>`;}).join('')}</div>`:empty('Start a little ritual','Add a habit that feels useful to you.','activity'))}</div>
 <div>${panel('New habit',`<form class="form-stack" id="habit-form"><label>Habit name<input name="title" required maxlength="100" placeholder="Read for 10 minutes"/></label><button class="btn btn-primary" type="submit">${ico('plus',17)}Create habit</button></form><p class="muted-small">No guilt, no forced streaks. Just your progress.</p>`)}</div></div>`;}
function studyPage(){const cards=data.flashcards;selectedCard=Math.min(selectedCard,Math.max(0,cards.length-1));const card=cards[selectedCard];return `${heading('LEARNING','Remember what matters.','Make your own flashcards and practice whenever you like.')}
 <div class="two-col study-layout"><div>${panel('Your practice deck',cards.length?`<div class="flashcard" data-action="flip-card" role="button" tabindex="0" aria-label="Flip flashcard"><p>${revealCard?'ANSWER':'QUESTION'} · CARD ${selectedCard+1} OF ${cards.length}</p><strong>${E(revealCard?card.answer:card.question)}</strong><small>${ico('repeat',14)}Tap to reveal ${revealCard?'question':'answer'}</small></div><div class="study-controls"><button class="btn btn-subtle" data-action="prev-card" ${selectedCard===0?'disabled':''}>Previous</button><button class="btn btn-primary" data-action="flip-card">${ico('repeat',16)}Flip</button><button class="btn btn-subtle" data-action="next-card" ${selectedCard===cards.length-1?'disabled':''}>Next</button></div><button class="text-link danger" data-delete="flashcard:${E(card.id)}">${ico('trash',15)}Delete this card</button>`:empty('Your blank slate','Create your first flashcard to study.','graduation-cap'))}</div>
 <div>${panel('Create a flashcard',`<form class="form-stack" id="flashcard-form"><label>Question<input name="question" maxlength="300" required placeholder="What is an atom?"/></label><label>Answer<textarea name="answer" maxlength="2000" required rows="5" placeholder="The answer you want to remember…"></textarea></label><button type="submit" class="btn btn-primary">${ico('plus',17)}Add card</button></form>`)}</div></div>`;}
function focusPage(){return `${heading('WELLNESS','Make time for focus.','A quiet timer for doing one thing at a time.')}
 <div class="timer-layout"><div class="panel timer-panel"><div class="focus-capsule">${ico('timer',16)} FOCUS SESSION</div><div class="timer-ring"><div id="timer-display" class="timer-digits">25:00</div><span id="timer-state">Ready when you are</span></div><div class="timer-actions"><button class="btn btn-primary btn-lg" data-action="toggle-timer" id="timer-toggle">${ico('check',17)}Start focusing</button><button class="btn btn-subtle btn-lg" data-action="reset-timer">Reset</button></div><div class="timer-durations">${[15,25,45,60].map(min=>`<button data-timer-minutes="${min}" class="filter-pill ${timerDuration===min*60?'on':''}">${min} min</button>`).join('')}</div></div>
 <div>${panel('Focus philosophy',`<div class="focus-copy"><span class="focus-icon">${ico('sun',29)}</span><h3>Less noise. More momentum.</h3><p>Choose a session, put distractions aside, and return to what matters. You can pause or reset at any time.</p><div class="focus-history"><strong>${data.sessions.length}</strong><span>Sessions completed and saved on this device</span></div></div>`)}</div></div>`;}
function passwordPage(){return `${heading('UTILITIES','A safer password in seconds.','Passwords are generated locally with your device’s cryptographic random number generator.')}
 <div class="password-layout"><section class="panel password-panel"><div class="password-intro">${ico('shield',27)}<div><h2>Password generator</h2><p>Nothing is sent to a server or saved in your workspace.</p></div></div><div class="password-result"><code id="password-output">${E(passwordValue||'Select Generate to begin')}</code><button class="icon-button" data-action="copy-password" title="Copy password">${ico('copy',20)}</button></div><div class="range-line"><label for="password-length">Password length</label><output id="password-length-text">20 characters</output></div><input type="range" id="password-length" min="8" max="48" value="20"/><button class="btn btn-primary btn-wide" data-action="generate-password">${ico('shield',17)}Generate secure password</button><p class="muted-small">Use a reputable password manager to store your passwords securely.</p></section></div>`;}
function writingPage(){const len=writingVal.length,words=writingVal.trim()?writingVal.trim().split(/\s+/).length:0;return `${heading('CREATE','Words, your way.','A distraction-free scratchpad and useful text transforms.')}
 <div class="panel writing-wrap"><div class="writing-toolbar"><span class="tool-group">WRITING STUDIO</span><div><button class="tool-text-button" data-action="uppercase">UPPERCASE</button><button class="tool-text-button" data-action="lowercase">lowercase</button><button class="tool-text-button" data-action="titlecase">Title Case</button><button class="tool-text-button" data-action="copy-writing">${ico('copy',15)}Copy</button></div></div><textarea id="writing-input" spellcheck="true" placeholder="Every great idea begins with a few words…">${E(writingVal)}</textarea><div class="writing-stats"><span id="writing-words">${words} words</span><span id="writing-chars">${len} characters</span><span id="writing-reading">~${Math.ceil(words/200)} min read</span><button class="text-link danger" data-action="clear-writing">Clear text</button></div></div>`;}
function jsonPage(){return `${heading('CREATE','JSON studio','Validate and format JSON without uploading it anywhere.')}
 <div class="json-grid"><div class="panel"><div class="panel-title"><h2>Input JSON</h2><button class="text-link" data-action="format-json">${ico('braces',16)}Format</button></div><textarea id="json-input" class="code-textarea" spellcheck="false" aria-label="JSON input">${E(jsonVal)}</textarea></div><div class="panel"><div class="panel-title"><h2>Result</h2><button class="text-link" data-action="copy-json">${ico('copy',15)}Copy</button></div><pre id="json-output" class="json-output">${E(jsonOutput||'Formatted output will appear here.')}</pre></div></div>`;}
function codePage(){return `${heading('CREATE','Code playground','Try HTML, CSS and JavaScript in a restricted preview frame.')}
 <div class="code-grid"><div class="panel"><div class="panel-title"><h2>HTML editor</h2><button class="btn btn-primary btn-sm" data-action="run-code">${ico('code',16)}Run</button></div><textarea class="code-textarea" id="code-input" spellcheck="false" aria-label="HTML editor">${E(codeVal)}</textarea></div><div class="panel"><div class="panel-title"><h2>Live preview</h2><span class="tool-group">SANDBOXED</span></div><iframe id="code-frame" title="HTML experiment preview" sandbox="allow-scripts" referrerpolicy="no-referrer"></iframe></div></div><p class="muted-small">The preview is sandboxed. Network connections and embedding external content are blocked by its content security policy.</p>`;}
function bookmarksPage(){return `${heading('ORGANIZE','Keep the good links.','A simple home for pages you want to revisit.')}
 <div class="two-col"><div>${panel('Saved links',data.bookmarks.length?`<div class="bookmark-list">${data.bookmarks.map(b=>`<div class="bookmark-row"><span class="bookmark-symbol">${ico('bookmark',19)}</span><div><strong>${E(b.title)}</strong><small>${E(b.url)}</small></div><a href="${E(b.url)}" target="_blank" rel="noopener noreferrer" class="icon-button" title="Open link" aria-label="Open ${E(b.title)}">${ico('external',17)}</a><button class="icon-button danger-on-hover" data-delete="bookmark:${E(b.id)}" aria-label="Delete bookmark">${ico('trash',16)}</button></div>`).join('')}</div>`:empty('No saved links','Collect your first favorite page.','bookmark'))}</div>
 <div>${panel('Add a bookmark',`<form class="form-stack" id="bookmark-form"><label>Name<input name="title" maxlength="120" required placeholder="Helpful website"/></label><label>URL<input name="url" type="url" maxlength="1000" required placeholder="https://example.com"/></label><button type="submit" class="btn btn-primary">${ico('plus',17)}Save bookmark</button></form>`)}</div></div>`;}

function goalsPage(){return `${heading('ORGANIZE','Progress worth tracking.','Set a target and build momentum in measurable steps.')}
 <div class="two-col"><div>${panel('Your goals',data.goals.length?`<div class="task-list">${data.goals.map(g=>`<div class="goal-row"><div class="goal-head"><strong>${E(g.title)}</strong><small>${E(String(g.current||0))} / ${E(String(g.target||1))} ${E(g.unit||'units')}</small></div><div class="progress-track"><span style="width:${Math.max(0,Math.min(100,Math.round((g.current||0)/(g.target||1)*100)))}%"></span></div><div class="goal-actions"><button class="btn btn-subtle btn-sm" data-goal-step="${E(g.id)}">+ ${E(String(g.step||1))}</button><button class="text-link danger" data-delete="goal:${E(g.id)}">Remove</button></div></div>`).join('')}</div>`:empty('Start one meaningful goal','Your goals and progress will appear here.','activity'))}</div><div>${panel('Create goal',`<form id="goal-form" class="form-stack"><label>Goal<input required name="title" maxlength="120" placeholder="e.g. Read 12 chapters" /></label><label>Target<input required name="target" type="number" min="1" max="1000000" step="any" value="12" /></label><label>Progress per click<input name="step" type="number" min="0.01" max="10000" step="any" value="1" /></label><label>Unit<input name="unit" maxlength="25" placeholder="chapters, pages, sessions…" /></label><button type="submit" class="btn btn-primary">${ico('plus',17)}Add goal</button></form>`)}</div></div>`;}
function datecalcPage(){let diff='—',from='—';try{const n=daysBetween(dateStart,dateEnd);diff=String(Math.abs(n));from=n===0?'Same day':n>0?'days after start':'days before start';}catch{}
 return `${heading('UTILITIES','Date calculator','Calculate exact calendar-day differences, independent of daylight saving time.')}
 <div class="panel date-tool"><div class="form-stack"><label>Start date<input id="date-start" type="date" value="${E(dateStart)}" /></label><label>End date<input id="date-end" type="date" value="${E(dateEnd)}" /></label><div class="date-answer"><strong id="date-diff">${E(diff)}</strong><span id="date-direction">${E(from)}</span></div><p class="muted-small">The difference excludes the starting day. Same date = 0 days. A full week = 7 days.</p></div></div>`;}
function textLabPage(){return `${heading('CREATE','Text lab','Understand your writing and transform it without uploading your text.')}
 <div class="panel textlab-panel"><textarea id="textlab-input" aria-label="Text to analyze" rows="11" placeholder="Paste text or write here...">${E(textLabValue)}</textarea><div class="text-stats" id="textlab-stats">${textStatsHtml(textLabValue)}</div><div class="textlab-actions"><button class="btn btn-subtle" data-action="text-trim">Trim whitespace</button><button class="btn btn-subtle" data-action="text-lines">Remove empty lines</button><button class="btn btn-subtle" data-action="text-dedupe">Remove duplicate lines</button><button class="btn btn-primary" data-action="text-copy">${ico('copy',17)}Copy result</button></div></div>`;}
function textStatsHtml(value){const t=String(value||''),trim=t.trim();return `<span><strong>${trim?trim.split(/\s+/).length:0}</strong>Words</span><span><strong>${t.length}</strong>Characters</span><span><strong>${trim?trim.split(/[.!?]+/).filter(s=>s.trim()).length:0}</strong>Sentences</span><span><strong>${t? t.split(/\r?\n/).length:0}</strong>Lines</span>`;}
function pickerPage(){return `${heading('UTILITIES','Decision picker','Make a fair random choice from a list, without ads or tracking.')}
 <div class="panel picker-panel"><label class="form-stack">Options, one per line<textarea id="picker-input" rows="8" placeholder="Option A&#10;Option B&#10;Option C">${E(pickerValue)}</textarea></label><div class="picker-output" id="picker-output">${pickerResult?E(pickerResult):'Your result appears here.'}</div><button class="btn btn-primary" data-action="pick-random">${ico('repeat',18)}Choose randomly</button><p class="muted-small">This is for casual decisions, not financial gambling, betting, or real-world risk.</p></div>`;}
function settingsPage(){return `${heading('WORKSPACE','Make it yours.','Manage your preferences and personal data.')}
 <div class="settings-grid"><div>${panel('Your space',`<form id="profile-form" class="form-stack"><label>What should we call you?<input name="name" required maxlength="40" value="${E(data.profile.name)}"/></label><label>Appearance<select name="theme"><option value="dark" ${data.profile.theme==='dark'?'selected':''}>Deep navy (default)</option><option value="light" ${data.profile.theme==='light'?'selected':''}>Light</option></select></label><button class="btn btn-primary" type="submit">${ico('check',17)}Save settings</button></form>`)}</div>
 <div>${panel('Your data',`<p class="settings-prose">Everything in this edition is saved in this browser’s local storage. It does not sync across devices automatically, and clearing browser data can erase it.</p><div class="settings-actions"><button class="btn btn-subtle" data-action="export">${ico('download',17)}Export backup</button><label class="btn btn-subtle file-label">${ico('upload',17)}Import backup<input type="file" id="import-file" accept="application/json,.json" hidden/></label></div><button class="text-link danger settings-delete" data-action="delete-all">Erase all local data</button>`)}</div>
 <div class="pricing-panel panel"><div class="pricing-header"><span class="eyebrow">FUTURE BUSINESS PLAN — NOT ACTIVE</span><h2>One app. Simple pricing.</h2><p>Proposed launch model, not a working checkout or entitlement system.</p></div><div class="price-grid"><div class="price-card"><span>Launch window</span><strong>Free</strong><p>First 6 months after the official launch date (to be configured).</p></div><div class="price-card"><span>Monthly</span><strong>AED 5<small>/month</small></strong><p>Planned recurring subscription after the free launch period.</p></div><div class="price-card featured"><span>Lifetime</span><strong>AED 75</strong><p>Planned one-time lifetime unlock (subject to platform rules).</p></div></div><div class="disclaimer pricing-disclaimer">${ico('shield',18)}Purchases are not enabled. Store billing, refunds, taxes, account login and secure license verification still require development.</div></div>
 <div>${panel('About #Infinity',`<div class="about-app"><img src="${logo}" alt="#Infinity blue and gold logo"/><div><strong>#Infinity</strong><p>Offline-first workspace · version 2.0.0</p><p>Designed for speed, clarity and useful everyday tools. No hidden subscriptions are collected.</p></div></div>`)}</div></div>`;}
function refresh(){renderPage();}
function addRecord(key,record){data[key].push({id:newId(),...record});save();refresh();toast('Saved to your workspace.');}
function readForm(form){return Object.fromEntries(new FormData(form).entries());}
function storeChat(){data.chats=chat.slice(-45).map(m=>({role:m.role,text:m.text,link:m.link||'',error:!!m.error}));save();}
function scrollChat(){const messages=document.getElementById('messages');if(messages)messages.scrollTop=messages.scrollHeight;}
async function pushChat(text){
 const prompt=String(text||'').trim();if(!prompt||chatBusy)return;
 const token=onlineAI && window.turnstile && turnstileWidget!==null?window.turnstile.getResponse(turnstileWidget):'';
 if(onlineAI&&!token){toast('Complete human verification to use the online AI.','error');return;}
 chat.push({role:'user',text:prompt.slice(0,5000)});storeChat();
 if(!onlineAI){chat.push({role:'bot',...localReply(prompt)});storeChat();refresh();scrollChat();return;}
 chatBusy=true;chatAbort=new AbortController();const asked=chat.slice(-24);const context=shareWorkspace?makeWorkspaceContext(data):'';
 shareWorkspace=false;refresh();scrollChat();
 try{const answer=await askOnlineAI({endpoint:AI_CONFIG.endpoint,messages:asked,mode:chatMode,context,turnstileToken:token,signal:chatAbort.signal});chat.push({role:'bot',text:answer.text});storeChat();}
 catch(err){if(err.name!=='AbortError'){chat.push({role:'bot',text:`Could not get an online answer: ${err.message}`,error:true});storeChat();toast('AI service unavailable.','error');}}
 finally{chatBusy=false;chatAbort=null;if(view==='assistant'){refresh();scrollChat();}}
}
function modifyText(action){const input=document.getElementById('writing-input');if(!input)return;
 if(action==='uppercase')input.value=input.value.toUpperCase();
 if(action==='lowercase')input.value=input.value.toLowerCase();
 if(action==='titlecase')input.value=input.value.toLowerCase().replace(/\b\p{L}/gu, x=>x.toUpperCase());
 writingVal=input.value;updateWritingStats();}
function updateWritingStats(){const s=writingVal.trim(),w=s?s.split(/\s+/).length:0;const wordEl=document.getElementById('writing-words'),charEl=document.getElementById('writing-chars'),readEl=document.getElementById('writing-reading');if(wordEl)wordEl.textContent=`${w} words`;if(charEl)charEl.textContent=`${writingVal.length} characters`;if(readEl)readEl.textContent=`~${Math.ceil(w/200)} min read`;}
function formatTime(sec){const n=Math.max(0,Math.ceil(sec));return `${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;}
function updateTimerDisplay(){const display=document.getElementById('timer-display'),status=document.getElementById('timer-state'),toggle=document.getElementById('timer-toggle');if(display)display.textContent=formatTime(timerRemaining);if(status)status.textContent=timerRunning?'You’re in the zone':'Ready when you are';if(toggle)toggle.innerHTML=timerRunning?`${ico('timer',17)}Pause session`:`${ico('check',17)}Start focusing`;
 const angle=(1-timerRemaining/timerDuration)*360;const ring=document.querySelector('.timer-ring');if(ring)ring.style.setProperty('--angle',`${Math.max(0,angle)}deg`);
}
const timerInterval=setInterval(()=>{if(!timerRunning)return;timerRemaining=Math.max(0,Math.ceil((timerEndAt-Date.now())/1000));updateTimerDisplay();if(timerRemaining===0){timerRunning=false;data.sessions.push({id:newId(),date:todayKey(),minutes:timerDuration/60});save();toast('Focus session complete. Excellent work!');if(view==='focus')refresh();}},500);
function updateCodeFrame(shouldRun){const frame=document.getElementById('code-frame');if(!frame)return;if(!shouldRun&&frame.dataset.loaded)return;const userCode=codeVal.slice(0,40000);const csp="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'; form-action 'none'; base-uri 'none'";frame.srcdoc=`<!DOCTYPE html><html><head><meta http-equiv="Content-Security-Policy" content="${csp}"><meta name="viewport" content="width=device-width, initial-scale=1"></head><body>${userCode}</body></html>`;frame.dataset.loaded='true';}
async function copyText(text){try{await navigator.clipboard.writeText(text);toast('Copied to clipboard.');}catch{toast('Clipboard access unavailable in this browser.','error');}}
function renderSearch(){document.querySelector('.search-backdrop')?.remove();const modal=document.createElement('div');modal.className='search-backdrop';modal.innerHTML=`<div class="search-modal" role="dialog" aria-modal="true" aria-label="Search your tools"><div class="modal-search">${ico('search',21)}<input id="command-search" placeholder="Search #Infinity…" autocomplete="off" value="${E(searchTerm)}"/><button class="icon-button" data-action="close-search" aria-label="Close search">${ico('x',18)}</button></div><div class="search-results"></div><div class="modal-hint">ESC to close · Tap a result to open</div></div>`;root.querySelector('.shell').appendChild(modal);renderSearchResults();setTimeout(()=>document.getElementById('command-search')?.focus(),0);}
function renderSearchResults(){const target=document.querySelector('.search-results');if(!target)return;
 const q=searchTerm.trim().toLowerCase();const found=TOOLS.filter(t=>`${t.name} ${t.desc} ${t.group}`.toLowerCase().includes(q));
 const hits=q.length>=2?data.notes.filter(n=>`${n.title} ${n.body}`.toLowerCase().includes(q)).slice(0,7):[];
 const tasks=q.length>=2?data.tasks.filter(t=>t.title.toLowerCase().includes(q)).slice(0,7):[];
 target.innerHTML=found.map(t=>`<button class="search-result" data-nav="${t.id}"><span class="tool-icon">${ico(t.icon,19)}</span><span><strong>${E(t.name)}</strong><small>Tool · ${E(t.group)}</small></span>${ico('arrow-right',17)}</button>`).join('')+hits.map(n=>`<button class="search-result" data-open-note="${E(n.id)}"><span class="tool-icon">${ico('file-text',19)}</span><span><strong>${E(n.title||'Untitled note')}</strong><small>Note · ${E((n.body||'').slice(0,55))}</small></span>${ico('arrow-right',17)}</button>`).join('')+tasks.map(t=>`<button class="search-result" data-nav="tasks"><span class="tool-icon">${ico('check-square',19)}</span><span><strong>${E(t.title)}</strong><small>Task · ${t.done?'done':'pending'}</small></span>${ico('arrow-right',17)}</button>`).join('')||empty('No matches','Search tools, your notes and your tasks.','search');}
function closeSearch(){searchOpen=false;searchTerm='';document.querySelector('.search-backdrop')?.remove();}
function handleAction(action){switch(action){
 case 'clear-chat': if(chat.length&&confirm('Clear your saved conversation?')){chat.length=0;storeChat();refresh();toast('Conversation cleared.');}break;
 case 'save-last-ai':{const m=[...chat].reverse().find(x=>x.role==='bot');if(!m){toast('No AI reply to save.','error');break;}const id=newId();data.notes.unshift({id,title:'From Infinity Assist',body:m.text,updated:new Date().toISOString()});save();selectedNote=id;navigate('notes');toast('Reply saved as a note.');break;}
 case 'copy-chat': copyText(chat.map(m=>`${m.role==='user'?'You':'Infinity'}: ${m.text}`).join('\n\n')||'No messages yet.');break;
 case 'cancel-chat':chatAbort?.abort();chatBusy=false;refresh();break;
 case 'text-copy':copyText(textLabValue);break;
 case 'text-trim':textLabValue=textLabValue.trim().replace(/[ \t]+$/gm,'');refresh();break;
 case 'text-lines':textLabValue=textLabValue.split(/\r?\n/).filter(s=>s.trim()).join('\n');refresh();break;
 case 'text-dedupe':textLabValue=[...new Set(textLabValue.split(/\r?\n/))].join('\n');refresh();break;
 case 'pick-random':{const opts=pickerValue.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);if(opts.length<2){toast('Enter at least two options.','error');break;}pickerResult=opts[secureRandomIndex(opts.length)];document.getElementById('picker-output').textContent=pickerResult;break;}
 case 'drawer-open': drawerOpen=true;shell();break;
 case 'drawer-close':drawerOpen=false;shell();break;
 case 'open-search':searchOpen=true;searchTerm='';renderSearch();break;
 case 'close-search':closeSearch();break;
 case 'theme':data.profile.theme=data.profile.theme==='dark'?'light':'dark';save();shell();break;
 case 'go-explore':navigate('explore');break;
 case 'focus-task':document.getElementById('task-title')?.focus();break;
 case 'new-note':{const id=newId();data.notes.unshift({id,title:'',body:'',updated:new Date().toISOString()});selectedNote=id;save();refresh();document.querySelector('.note-title-input')?.focus();break;}
 case 'swap-units':[convertFrom,convertTo]=[convertTo,convertFrom];refresh();break;
 case 'flip-card':revealCard=!revealCard;refresh();break;
 case 'next-card':selectedCard=Math.min(selectedCard+1,data.flashcards.length-1);revealCard=false;refresh();break;
 case 'prev-card':selectedCard=Math.max(0,selectedCard-1);revealCard=false;refresh();break;
 case 'toggle-timer':if(timerRunning){timerRemaining=Math.max(0,Math.ceil((timerEndAt-Date.now())/1000));timerRunning=false;}else {timerEndAt=Date.now()+timerRemaining*1000;timerRunning=true;}updateTimerDisplay();break;
 case 'reset-timer':timerRunning=false;timerRemaining=timerDuration;updateTimerDisplay();break;
 case 'generate-password':{const len=Number(document.getElementById('password-length')?.value||20);try{passwordValue=randomPassword(len);document.getElementById('password-output').textContent=passwordValue;}catch(e){toast(e.message,'error');}break;}
 case 'copy-password':if(passwordValue)copyText(passwordValue);else toast('Generate a password first.','error');break;
 case 'uppercase':case 'lowercase':case 'titlecase':modifyText(action);break;
 case 'copy-writing':copyText(writingVal);break;
 case 'clear-writing':writingVal='';document.getElementById('writing-input').value='';updateWritingStats();break;
 case 'format-json':{jsonVal=document.getElementById('json-input')?.value||'';try{jsonOutput=JSON.stringify(JSON.parse(jsonVal),null,2);document.getElementById('json-output').textContent=jsonOutput;toast('Valid JSON.');}catch(e){jsonOutput=`Invalid JSON: ${e.message}`;document.getElementById('json-output').textContent=jsonOutput;toast('Invalid JSON.','error');}break;}
 case 'copy-json':if(jsonOutput)copyText(jsonOutput);break;
 case 'run-code':codeVal=document.getElementById('code-input')?.value||'';updateCodeFrame(true);toast('Preview refreshed.');break;
 case 'export':{const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const u=URL.createObjectURL(blob);const a=document.createElement('a');a.href=u;a.download=`hash-infinity-backup-${todayKey()}.json`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),2000);toast('Backup downloaded.');break;}
 case 'delete-all':if(confirm('Erase all saved #Infinity data on this device? This cannot be undone without a backup.')){data=clone(DEFAULT_STATE);selectedNote=null;chat.length=0;save();navigate('home');toast('Local workspace reset.');}break;
 }
}
root.addEventListener('click',e=>{
 const b=e.target.closest('button,a,[role="button"]');if(!b)return;
 if(b.matches('[data-nav]')){e.preventDefault();navigate(b.dataset.nav);return;}
 if(b.dataset.action){if(b.hasAttribute('disabled'))return;handleAction(b.dataset.action);return;}
 if(b.dataset.openNote){selectedNote=b.dataset.openNote;navigate('notes');return;}
 if(b.dataset.filter){filterGroup=b.dataset.filter;refresh();return;}
 if(b.dataset.pin){const id=b.dataset.pin;if(data.profile.pinned.includes(id))data.profile.pinned=data.profile.pinned.filter(x=>x!==id);else data.profile.pinned.push(id);save();refresh();toast('Favorites updated.');return;}
 if(b.dataset.ask){pushChat(b.dataset.ask);return;}
 if(b.dataset.goalStep){const g=data.goals.find(x=>x.id===b.dataset.goalStep);if(g){g.current=Math.min(g.target,Number(((g.current||0)+g.step).toFixed(6)));save();refresh();}return;}
 if(b.dataset.toggleTask){const t=data.tasks.find(x=>x.id===b.dataset.toggleTask);if(t){t.done=!t.done;save();refresh();}return;}
 if(b.dataset.toggleHabit){const h=data.habits.find(x=>x.id===b.dataset.toggleHabit);if(h){const set=new Set((h.days||'').split('|').filter(Boolean));const k=todayKey();if(set.has(k))set.delete(k);else set.add(k);h.days=[...set].join('|');save();refresh();}return;}
 if(b.dataset.delete){const [kind,id]=b.dataset.delete.split(':');const map={task:'tasks',note:'notes',plan:'plans',expense:'expenses',habit:'habits',flashcard:'flashcards',bookmark:'bookmarks',goal:'goals'};const k=map[kind];if(!k)return;data[k]=data[k].filter(x=>x.id!==id);if(kind==='note'&&selectedNote===id)selectedNote=null;if(kind==='flashcard'){selectedCard=0;revealCard=false;}save();refresh();toast('Item removed.');return;}
 if(b.dataset.calc){const value=b.dataset.calc;if(value==='C')calcInput='0';else if(value==='='){try{calcInput=String(calc(calcInput));}catch(err){toast(err.message,'error');}}else{const c=value==='×'?'*':value==='÷'?'/':value==='−'?'-':value;calcInput=calcInput==='0'&&/\d/.test(c)?c:calcInput+c;}const display=document.getElementById('calc-screen');if(display)display.textContent=calcInput;return;}
 if(b.dataset.calcExample){calcInput=b.dataset.calcExample;document.getElementById('calc-screen').textContent=calcInput;return;}
 if(b.dataset.convertGroup){convertType=b.dataset.convertGroup;const units=Object.keys(UNIT_GROUPS[convertType]);convertFrom=units[0];convertTo=units[1];refresh();return;}
 if(b.dataset.timerMinutes){timerDuration=Number(b.dataset.timerMinutes)*60;timerRemaining=timerDuration;timerRunning=false;refresh();return;}
});
root.addEventListener('submit',e=>{
 const f=e.target;if(!(f instanceof HTMLFormElement))return;e.preventDefault();const v=readForm(f);
 if(f.getAttribute('id')==='task-form'){const title=String(v.title||'').trim();if(title)addRecord('tasks',{title,due:v.due||'',priority:v.priority||'normal',done:false});}
 if(f.getAttribute('id')==='note-form'){const n=data.notes.find(x=>x.id===v.id);if(n){n.title=String(v.title||'').trim().slice(0,200);n.body=String(v.body||'').slice(0,30000);n.updated=new Date().toISOString();save();refresh();toast('Note saved.');}}
 if(f.getAttribute('id')==='plan-form'){if(v.date&&String(v.title).trim())addRecord('plans',{title:String(v.title).trim(),date:v.date,time:v.time||''});}
 if(f.getAttribute('id')==='expense-form'){const amt=Number(v.amount);if(amt>0&&amt<=1e9&&String(v.title).trim())addRecord('expenses',{title:String(v.title).trim(),amount:amt,category:v.category||'Other',date:v.date||todayKey()});}
 if(f.getAttribute('id')==='trade-form'){
  const ticker=String(v.ticker||'').toUpperCase(),qty=Number(v.qty),price=Number(v.price),side=v.side;
  if(!/^[A-Z0-9.\-]{1,12}$/.test(ticker)||!(qty>0)||!(price>0)||!Number.isFinite(qty*price)||qty*price>1e9){toast('Enter a valid symbol, quantity and price.','error');return;}
  const pf=portfolio(data.trades,data.quotes);
  if(side==='buy'&&pf.cash+1e-7<qty*price){toast('Not enough pretend cash.','error');return;}
  if(side==='sell'&&(pf.positions.find(p=>p.ticker===ticker)?.qty||0)+1e-7<qty){toast('Not enough pretend units to sell.','error');return;}
  data.quotes[ticker]=price;addRecord('trades',{ticker,qty,price,side,date:todayKey()});
 }
 if(f.getAttribute('id')==='habit-form'){if(String(v.title||'').trim())addRecord('habits',{title:String(v.title).trim(),days:''});}
 if(f.getAttribute('id')==='flashcard-form'){if(String(v.question||'').trim()&&String(v.answer||'').trim()){addRecord('flashcards',{question:String(v.question).trim(),answer:String(v.answer).trim()});selectedCard=data.flashcards.length-1;revealCard=false;refresh();}}
 if(f.getAttribute('id')==='bookmark-form'){const url=validHttpUrl(String(v.url||''));if(!url){toast('Only http:// and https:// links are allowed.','error');return;}addRecord('bookmarks',{title:String(v.title||'').trim(),url});}
 if(f.getAttribute('id')==='profile-form'){data.profile.name=String(v.name||'Explorer').trim().slice(0,40)||'Explorer';data.profile.theme=v.theme==='light'?'light':'dark';save();shell();toast('Settings saved.');}
 if(f.getAttribute('id')==='chat-form'){const msg=String(v.message||'').trim();pushChat(msg);}
 if(f.getAttribute('id')==='goal-form'){const title=String(v.title||'').trim(),target=Number(v.target),step=Number(v.step);if(title&&target>0&&target<=1e6&&step>0&&step<=10000){addRecord('goals',{title,target,step,current:0,unit:String(v.unit||'units').slice(0,25)});}else toast('Enter a valid goal and progress target.','error');}
});
root.addEventListener('input',e=>{
 const t=e.target;
 if(t.id==='ai-context'){shareWorkspace=t.checked;return;}
 if(t.id==='textlab-input'){textLabValue=t.value;document.getElementById('textlab-stats').innerHTML=textStatsHtml(textLabValue);return;}
 if(t.id==='picker-input'){pickerValue=t.value;return;}
 if(t.id==='date-start'||t.id==='date-end'){dateStart=document.getElementById('date-start').value;dateEnd=document.getElementById('date-end').value;try{const diff=daysBetween(dateStart,dateEnd);document.getElementById('date-diff').textContent=String(Math.abs(diff));document.getElementById('date-direction').textContent=diff===0?'Same day':diff>0?'days after start':'days before start';}catch{}return;}
 if(t.id==='explore-query'){searchTerm=t.value;const cursor=t.selectionStart;refresh();const field=document.getElementById('explore-query');if(field){field.focus();field.setSelectionRange(cursor,cursor);}return;}
 if(t.id==='command-search'){searchTerm=t.value;renderSearchResults();return;}
 if(t.id==='writing-input'){writingVal=t.value;updateWritingStats();return;}
 if(t.id==='json-input'){jsonVal=t.value;return;}
 if(t.id==='code-input'){codeVal=t.value;return;}
 if(t.id==='convert-input'){convertVal=t.value;updateConversion();return;}
 if(t.id==='password-length'){document.getElementById('password-length-text').textContent=`${t.value} characters`;return;}
});
function updateConversion(){let result='—';try{result=humanNum(convert(convertVal,convertType,convertFrom,convertTo));}catch{}const el=document.getElementById('convert-result');if(el)el.textContent=result;}
root.addEventListener('change',async e=>{const t=e.target;
 if(t.id==='ai-mode'){chatMode=t.value;return;}
 if(t.id==='convert-from'){convertFrom=t.value;updateConversion();}
 if(t.id==='convert-to'){convertTo=t.value;updateConversion();}
 if(t.id==='import-file' && t.files?.[0]){
  const file=t.files[0];if(file.size>10*1024*1024){toast('Backup file is too large.','error');return;}
  try{const candidate=safeImport(await file.text());if(!confirm('Replace all existing local data with this backup?'))return;data=candidate;chat=Array.isArray(data.chats)?data.chats:[];save();selectedNote=null;selectedCard=0;navigate('home');toast('Backup imported.');}catch(err){toast(`Could not import backup: ${err.message}`,'error');}t.value='';
 }
});
document.addEventListener('keydown',e=>{
 if(view==='assistant'&&e.target.matches('#chat-form textarea')&&(e.ctrlKey||e.metaKey)&&e.key==='Enter'){e.preventDefault();e.target.closest('form')?.requestSubmit();return;}
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();searchOpen=true;searchTerm='';renderSearch();return;}
 if(e.key==='Escape'&&searchOpen){closeSearch();return;}
 if(view==='study'&&e.key==='Enter'&&e.target.matches('.flashcard')){e.preventDefault();handleAction('flip-card');return;}
 if(view==='calculator'&&document.activeElement?.tagName!=='INPUT'&&!searchOpen){
  if(/[\d()+\-*/%^.]/.test(e.key)&&e.key.length===1){e.preventDefault();calcInput=calcInput==='0'&&/\d/.test(e.key)?e.key:calcInput+e.key;document.getElementById('calc-screen').textContent=calcInput;}
  if(e.key==='Enter'||e.key==='='){e.preventDefault();try{calcInput=String(calc(calcInput));document.getElementById('calc-screen').textContent=calcInput;}catch(err){toast(err.message,'error');}}
  if(e.key==='Backspace'){e.preventDefault();calcInput=calcInput.slice(0,-1)||'0';document.getElementById('calc-screen').textContent=calcInput;}
 }
});
if('serviceWorker' in navigator && location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
shell();
