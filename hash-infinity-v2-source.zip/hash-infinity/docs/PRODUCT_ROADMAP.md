# Product roadmap

## Shipped in source package (2.0)

- 20 local tools for practical productivity, writing, learning, utilities and simulated finances
- Local persistent conversation history, AI modes, Gemini API gateway integration and opt-in context
- Public deploy scaffold + Cloudflare Worker with Turnstile and approximate rate limits
- Universal note/task search, answer-to-note workflow, data import/export

## Not shipped, and not promised without budget/credentials/testing

- Live Gemini deployment and advanced reasoning benchmarking versus proprietary models
- Accounts, authenticated encrypted synchronization, cloud backup, multi-user profiles
- Real financial trading or real-time brokerage services
- Background jobs and secure personal connections to other services
- Payments, six-month free launch enforcement and store-compliant subscription management
- Android/iOS signed binaries and marketplace listings

## Recommended validation order

1. Connect a cloud account and configure secure AI secrets; confirm actual quota and privacy terms.
2. Publish GitHub Pages, run manual browser tests, collect reproducible bug reports.
3. Improve accessibility, keyboard/touch interactions, robustness under realistic data volume, and recovery from full storage.
4. Add identity, sync, abuse controls and deployment monitoring if the audience grows.
5. Prepare native store packaging and payment entitlements only after the core app reaches stability.

More features should be added according to actual demand, not by creating empty buttons or misleading labels.
